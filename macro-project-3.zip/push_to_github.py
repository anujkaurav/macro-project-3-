"""
Git Manager Script for Pushing Project to GitHub
Supports token-based push and SSH for https://github.com/anujkaurav/macro-project-3-.git
"""
import os
import sys
import getpass
from dulwich import porcelain
from dulwich.repo import Repo
from dulwich.client import get_transport_and_path

REMOTE_URL = "https://github.com/anujkaurav/macro-project-3-.git"


def init_and_commit():
    repo_path = "."
    if not os.path.exists(".git"):
        print("[1/3] Initializing local Git repository...")
        repo = porcelain.init(repo_path)
    else:
        repo = Repo(repo_path)
        print("[1/3] Existing Git repository detected.")

    print("[2/3] Staging all project files...")
    porcelain.add(repo, paths=["."])

    # Check status
    status = porcelain.status(repo)
    staged_adds = status.staged.get("add", [])
    staged_mods = status.staged.get("modify", [])
    print(f"      Staged {len(staged_adds)} new files, {len(staged_mods)} modified files.")

    if staged_adds or staged_mods:
        print("[3/3] Committing files to main branch...")
        commit_sha = porcelain.commit(
            repo,
            message=b"Complete Hybrid ML-DL Stock Market Trend Prediction & Technical Analysis Framework for Project Expo",
            author=b"Anuj Kaurav <anujkaurav@users.noreply.github.com>",
            committer=b"Anuj Kaurav <anujkaurav@users.noreply.github.com>"
        )
        print(f"      Committed successfully: {commit_sha.decode()[:8]}")
        # Ensure main branch ref and HEAD are set
        repo.refs[b"refs/heads/main"] = commit_sha
        repo.refs.set_symbolic_ref(b"HEAD", b"refs/heads/main")
    else:
        print("[3/3] Working tree clean, nothing to commit.")

    # Configure origin remote
    config = repo.get_config()
    section = (b"remote", b"origin")
    config.set(section, b"url", REMOTE_URL.encode())
    config.write_to_path()
    print(f"      Remote 'origin' set to: {REMOTE_URL}")

    return repo


def push_repo(token=None):
    repo = Repo(".")
    push_url = REMOTE_URL
    if token:
        token = token.strip()
        if "@" in token:
            # Full URL or user:token format passed
            push_url = f"https://{token}@github.com/anujkaurav/macro-project-3-.git"
        else:
            # Use GitHub username or token directly
            push_url = f"https://anujkaurav:{token}@github.com/anujkaurav/macro-project-3-.git"

    print(f"[*] Pushing 'main' branch to GitHub repository...")
    print(f"    Target: https://github.com/anujkaurav/macro-project-3-.git")
    try:
        porcelain.push(repo, push_url, refspecs=[b"refs/heads/main:refs/heads/main"])
        print("\n[+] SUCCESS! Project successfully pushed to:")
        print(f"    https://github.com/anujkaurav/macro-project-3-")
        return True
    except Exception as e:
        print(f"\n[!] Push failed: {type(e).__name__}: {e}")
        print("    Please check that your GitHub token has 'repo' write permissions.")
        return False


if __name__ == "__main__":
    init_and_commit()

    token_arg = None
    if len(sys.argv) > 1:
        token_arg = sys.argv[1]
    elif os.environ.get("GITHUB_TOKEN"):
        token_arg = os.environ.get("GITHUB_TOKEN")
    
    if token_arg:
        push_repo(token_arg)
    else:
        print("\n" + "=" * 70)
        print(" GitHub requires an authentication token to push to your repository:")
        print(" 1. Create a GitHub Personal Access Token at:")
        print("    https://github.com/settings/tokens (Classic or Fine-grained with 'repo' scope)")
        print(" 2. Run:")
        print("    python push_to_github.py <YOUR_GITHUB_TOKEN>")
        print("=" * 70)
