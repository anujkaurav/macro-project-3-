"""
Segment 6: Autonomous Incident Detection & Self-Healing Flow
Persona: Sub-Inspector Jitendra Singh (Bhopal Traffic Police On-Ground Officer)

Solves:
Vehicle breakdown or accident on Chetak Bridge / Board Office causing massive upstream choke.
Autonomously detects anomalies and reroutes incoming flow.
"""

from typing import Dict, List, Optional

class IncidentSelfHealingManager:
    """
    Monitors lane velocities and stationary vehicles to identify traffic incidents,
    then automatically triggers upstream flow-rate reduction and VMS rerouting.
    """
    def __init__(self):
        self.active_incidents: Dict[str, dict] = {}

    def report_incident(
        self,
        node_id: str,
        lane_id: str,
        incident_type: str,
        severity: str = "HIGH"
    ):
        """
        Triggered by computer vision tracking (stationary vehicle > 45s in active lane).
        """
        self.active_incidents[node_id] = {
            "lane_id": lane_id,
            "type": incident_type,
            "severity": severity,
            "upstream_throttled": True
        }
        print(f"\n⚠️ [INCIDENT DETECTED AT {node_id}]")
        print(f"Type: {incident_type} on Lane: {lane_id} (Severity: {severity})")

    def get_healing_actions(self, node_id: str, upstream_node_id: Optional[str]) -> Dict[str, any]:
        """
        Generates compensatory signal adjustments:
        - Throttles upstream feeder green time
        - Signals Variable Message Sign (VMS) detour instructions
        """
        if node_id not in self.active_incidents:
            return {"status": "NORMAL"}

        incident = self.active_incidents[node_id]
        actions = {
            "incident_node": node_id,
            "local_action": "REDUCE_PHASE_FOR_BLOCKED_LANE",
            "vms_advisory": f"Congestion ahead at {node_id}. Divert via Subhash Nagar Overbridge / Link Road 2."
        }

        if upstream_node_id:
            actions["upstream_action"] = {
                "node_id": upstream_node_id,
                "action": "THROTTLE_FEEDER_GREEN_BY_40_PERCENT",
                "reason": "Preventing queue spillback into incident zone"
            }

        return actions
