# BHOPAL-NET: Autonomous Multi-Agent Smart Traffic Management & Emergency Preemption System

An intelligent, decentralized traffic management system designed for **Bhopal City**, replacing static timer cycles with real-time adaptive AI control across 5 critical arterial intersections.

---

## 📍 Bhopal 5-Intersection Testbed Network
1. **Node 1: AIIMS Bhopal Roundabout (Saket Nagar)** — Emergency trauma center hub & Hoshangabad Road corridor entry.
2. **Node 2: Rani Kamlapati (RKMP) Station Junction (Habibganj)** — Multimodal transit exchange (Bhopal BRTS + Railway).
3. **Node 3: Board Office Square (DB City Mall Arterial)** — Core commercial bottleneck and highest-density junction.
4. **Node 4: Jyoti Talkies Square (MP Nagar Zone-1)** — Commercial feeder with high turning ratios.
5. **Node 5: Roshanpura Square (New Market & Raj Bhavan Link)** — Dense pedestrian market area & VIP movement route.

---

## 👥 Segment Breakdown & Assigned Personas

| Segment | Problem Solved | Assigned Persona | Key Technical Solution |
| :--- | :--- | :--- | :--- |
| **1. Corridor Synchronization** | Spillback jams from DB Mall to RKMP | **Er. Alok Shrivastava** (BSCDCL Traffic Engineer) | Decentralized MARL with neighbor pressure exchange |
| **2. Emergency Preemption** | Ambulance delays on Hoshangabad Rd | **Dr. Shalini Saxena & Driver Mohd. Rafeeq** (AIIMS Bhopal) | Multi-hop pre-flushing (clears 1-2 nodes ahead) + soft recovery |
| **3. Transit & Pedestrian (VRU)** | Pedestrian stranding at New Market & bus delay | **Rameshwar Dayal** (Senior Pedestrian) & **Mohan Patel** (Chalo Bus Driver) | Dynamic walk time extension ($<0.8\text{ m/s}$) + Passenger-capacity weighting |
| **4. V2X GLOSA Speed Advisory** | Stop-and-go fuel burn & phantom jams | **Ankit Malviya** (Daily Commuter / Auto Driver) | Real-time advisory speed broadcast ($V_{\text{target}} = \frac{D}{T_{\text{to\_green}}}$) |
| **5. Adverse Weather Fusion** | Camera failure in monsoon & lake fog | **Neha Kulkarni** (IoT Hardware Field Lead) | 77 GHz mmWave Radar + Optical Vision Kalman Filter |
| **6. Incident Self-Healing** | Breakdown on Chetak Bridge flyover | **SI Jitendra Singh** (Bhopal Traffic Police) | Stationary vehicle anomaly detection + Upstream diversion throttling |
| **7. Eco-Emissions Optimization** | High toxic PM2.5/NOx idling at MP Nagar | **Dr. V. K. Joshi** (MP Pollution Control Board) | Multi-objective Pareto optimization balancing delay & emissions |
| **8. Digital Twin Command Center** | Unexplainable black-box AI decisions | **Sunita Sharma** (Smart City CCCC Operator) | Live WebSockets telemetry dashboard with explainable AI |

---

## 📁 Codebase Architecture
```
bhopal_smart_traffic/
├── config.py                 # Bhopal nodes, coordinates, PCU & vehicle occupancy factors
├── marl_controller.py        # Decentralized multi-agent reinforcement learning pressure controller
├── emergency_corridor.py     # Multi-hop ambulance preemption & pre-flushing manager
├── pedestrian_transit.py     # Chalo bus priority & adaptive crosswalk safety engine
├── v2x_glosa.py              # Green Light Optimal Speed Advisory engine
├── incident_self_healing.py  # Anomaly detection & upstream diversion controller
├── main_simulation.py        # End-to-end integrated simulation driver
└── README.md                 # Project documentation
```

---

## 🚀 How to Run the Integrated Simulation

Ensure Python is installed on your system, then open a terminal in the project directory and run:

```bash
python -m bhopal_smart_traffic.main_simulation
```
