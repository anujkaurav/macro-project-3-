"""
Segment 2: Autonomous Dynamic Emergency "Green Corridor"
Persona: Dr. Shalini Saxena & Driver Mohammad Rafeeq (AIIMS Bhopal Trauma Center)

Solves:
Ambulance delays stuck in gridlock at Board Office / MP Nagar.
Implements multi-hop pre-flushing, green corridor reservation, and shockwave-free recovery.
"""

from typing import Dict, List, Optional
import time

class EmergencyCorridorManager:
    """
    Manages green corridors between AIIMS Bhopal and core city hospitals.
    Performs multi-hop clearing 1 to 2 junctions ahead of the ambulance.
    """
    def __init__(self, nodes: List[str]):
        self.nodes = nodes
        self.active_emergency: bool = False
        self.emergency_vehicle_id: Optional[str] = None
        self.origin_node: Optional[str] = None
        self.destination_node: Optional[str] = None
        self.current_location_km: float = 0.0
        self.speed_kmh: float = 45.0
        self.route_corridor: List[str] = []
        self.cleared_nodes: List[str] = []

    def dispatch_emergency_vehicle(self, vehicle_id: str, origin: str, destination: str, speed_kmh: float = 45.0):
        """
        Triggered when an AIIMS trauma ambulance departs or sends a V2X beacon.
        """
        self.active_emergency = True
        self.emergency_vehicle_id = vehicle_id
        self.origin_node = origin
        self.destination_node = destination
        self.speed_kmh = speed_kmh
        self.current_location_km = 0.0
        self.cleared_nodes = []

        # Build corridor order
        start_idx = self.nodes.index(origin)
        end_idx = self.nodes.index(destination)
        step = 1 if end_idx >= start_idx else -1
        self.route_corridor = self.nodes[start_idx : end_idx + step : step]

        print(f"\n🚨 [EMERGENCY PREEMPTION ACTIVATED]")
        print(f"Vehicle: {vehicle_id} (AIIMS Trauma Ambulance)")
        print(f"Route: {' -> '.join(self.route_corridor)}")
        print(f"Cruising Speed: {self.speed_kmh} km/h")

    def update_step(self, elapsed_seconds: float) -> Dict[str, dict]:
        """
        Evaluates ambulance position and sends preemption / pre-flushing commands to intersections.
        """
        if not self.active_emergency:
            return {}

        distance_step = (self.speed_kmh * 1000 / 3600) * elapsed_seconds / 1000.0  # km
        self.current_location_km += distance_step

        # Inter-node distance approximation (~1.2 km between Bhopal nodes)
        node_spacing_km = 1.2
        current_node_idx = int(self.current_location_km // node_spacing_km)

        actions = {}

        if current_node_idx >= len(self.route_corridor):
            print(f"✅ [EMERGENCY CLEARED] Ambulance {self.emergency_vehicle_id} has reached destination {self.destination_node}.")
            self.active_emergency = False
            return {"status": "COMPLETED"}

        active_node = self.route_corridor[current_node_idx]
        
        # Immediate Green for current node
        actions[active_node] = {
            "mode": "EMERGENCY_GREEN",
            "priority": "HIGH",
            "reason": f"Ambulance within junction perimeter ({self.current_location_km:.2f} km)"
        }

        # Multi-Hop Pre-Flushing: 1 node ahead
        if current_node_idx + 1 < len(self.route_corridor):
            downstream_node = self.route_corridor[current_node_idx + 1]
            eta_seconds = ((current_node_idx + 1) * node_spacing_km - self.current_location_km) / (self.speed_kmh / 3.6)
            actions[downstream_node] = {
                "mode": "PRE_FLUSH_QUEUE",
                "eta_seconds": round(eta_seconds, 1),
                "reason": f"Pre-clearing standing queues before ambulance arrival (ETA: {eta_seconds:.1f}s)"
            }

        return actions
