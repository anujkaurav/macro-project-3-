"""
Segment 1 & 7: Multi-Agent Reinforcement Learning (MARL) & Eco-Emissions Optimizer
Persona: Er. Alok Shrivastava (BSCDCL) & Dr. V. K. Joshi (MP Pollution Control Board)

Solves:
The 'Balloon Effect' (spillback queues from Board Office to RKMP) and high idling emissions.
Implements Pressure-based coordination and multi-objective Pareto optimization.
"""

from typing import Dict, List
import random
from .config import VEHICLE_WEIGHTS

class MARLIntersectionAgent:
    """
    Decentralized RL Agent for a single intersection.
    Uses Max-Pressure and neighbor exchange to avoid choking adjacent junctions.
    """
    def __init__(self, node_id: str, neighbors: List[str]):
        self.node_id = node_id
        self.neighbors = neighbors
        self.current_phase = 0  # 0: North-South (Arterial), 1: East-West (Cross)
        self.current_phase_duration = 20
        self.min_green = 15
        self.max_green = 65

    def compute_pressure(self, lane_queues: Dict[str, int], neighbor_queues: Dict[str, int]) -> float:
        """
        Calculates intersection pressure:
        Pressure = Inflow Queues - Outflow Capacities (avoiding dumping into congested neighbors)
        """
        inflow = sum(lane_queues.values())
        outflow_penalty = 0.0

        for neighbor in self.neighbors:
            # If neighbor is choked, penalize pushing more traffic towards them
            neighbor_q = neighbor_queues.get(neighbor, 0)
            if neighbor_q > 35:
                outflow_penalty += (neighbor_q - 35) * 1.5

        pressure = inflow + outflow_penalty
        return pressure

    def select_action(self, lane_queues: Dict[str, int], neighbor_queues: Dict[str, int]) -> int:
        """
        Action: Choose green time extension for the most congested phase.
        Decentralized policy prioritizing max-pressure reduction.
        """
        pressure = self.compute_pressure(lane_queues, neighbor_queues)
        
        # Determine adaptive phase duration
        if pressure > 50:
            target_green = self.max_green
        elif pressure > 25:
            target_green = 35
        else:
            target_green = self.min_green
            
        return target_green

    def compute_reward(self, delay: float, emissions_kg: float, queue_length: int) -> float:
        """
        Segment 7: Multi-objective Eco-Emissions Reward
        R = - (alpha * Delay + beta * Emissions + gamma * Queue^2)
        """
        alpha = 0.4
        beta = 0.3
        gamma = 0.3
        reward = -(alpha * delay + beta * (emissions_kg * 10) + gamma * (queue_length ** 1.3))
        return reward
