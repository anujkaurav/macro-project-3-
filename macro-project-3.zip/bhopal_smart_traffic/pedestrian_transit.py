"""
Segment 3: Transit Signal Priority (TSP) & Pedestrian / VRU Safety
Persona: Rameshwar Dayal (Elderly Pedestrian at Roshanpura) & Mohan Patel ('Chalo' Bus Driver)

Solves:
Pedestrians trapped on medians at New Market & 60-passenger buses waiting behind 2 cars.
"""

from typing import Dict, List
from .config import VEHICLE_WEIGHTS

class TransitAndPedestrianController:
    """
    Evaluates passenger capacity and crosswalk safety to adapt signal timing.
    """
    def __init__(self, node_id: str):
        self.node_id = node_id

    def calculate_phase_weight_by_people(self, vehicle_counts: Dict[str, int]) -> float:
        """
        Prioritizes moving PEOPLE, not just metal vehicles.
        Calculates total passenger payload for a phase.
        """
        total_people = 0.0
        for v_type, count in vehicle_counts.items():
            occupancy = VEHICLE_WEIGHTS.get(v_type, {}).get("avg_occupancy", 1.5)
            total_people += count * occupancy
        return total_people

    def adaptive_pedestrian_clearance(
        self,
        base_walk_time_sec: int,
        pedestrian_count: int,
        vulnerable_pedestrian_detected: bool,
        measured_speed_mps: float
    ) -> Dict[str, any]:
        """
        Dynamic crosswalk extension at Roshanpura / New Market.
        If an elderly or mobility-impaired pedestrian is detected (speed < 0.9 m/s),
        dynamically extends the safe clearance phase up to safety cap.
        """
        adjusted_time = base_walk_time_sec
        extension_reason = "Standard walking pace"

        if vulnerable_pedestrian_detected or measured_speed_mps < 0.9:
            # Add up to 10-14 seconds extension for safe median-to-kerb crossing
            extension = min(14, int((0.9 - measured_speed_mps) * 15) + 6)
            adjusted_time += extension
            extension_reason = f"Elderly/slow walker detected ({measured_speed_mps:.2f} m/s) -> +{extension}s safety extension"
        elif pedestrian_count > 15:
            # High-density crowd (New Market shopping rush)
            adjusted_time += 6
            extension_reason = f"High pedestrian density ({pedestrian_count} people) -> +6s extension"

        return {
            "allocated_walk_sec": adjusted_time,
            "extension_sec": adjusted_time - base_walk_time_sec,
            "reason": extension_reason
        }
