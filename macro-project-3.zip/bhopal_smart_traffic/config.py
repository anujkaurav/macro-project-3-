"""
Bhopal Urban Corridor Configuration & Intersection Topology
Defines the 5 core intersections, GPS coordinates, traffic phase matrices,
and Indian heterogeneous vehicle mix parameters.
"""

from dataclasses import dataclass, field
from typing import List, Dict

@dataclass
class IntersectionNode:
    node_id: str
    name: str
    latitude: float
    longitude: float
    description: str
    connected_nodes: List[str]
    default_cycle_time: int = 90
    min_green_time: int = 15
    max_green_time: int = 65
    has_pedestrian_crosswalk: bool = True
    has_brts_corridor: bool = False

# Bhopal 5-Node Arterial Corridor
BHOPAL_NODES: Dict[str, IntersectionNode] = {
    "NODE_1_AIIMS": IntersectionNode(
        node_id="NODE_1_AIIMS",
        name="AIIMS Bhopal Roundabout (Saket Nagar)",
        latitude=23.2062,
        longitude=77.4608,
        description="Emergency trauma hub & Hoshangabad Rd entry point.",
        connected_nodes=["NODE_2_RKMP"],
        has_brts_corridor=True,
    ),
    "NODE_2_RKMP": IntersectionNode(
        node_id="NODE_2_RKMP",
        name="Rani Kamlapati Station Square (Habibganj)",
        latitude=23.2185,
        longitude=77.4395,
        description="Multimodal transit hub (Rail + BRTS + Link Road).",
        connected_nodes=["NODE_1_AIIMS", "NODE_3_BOARD_OFFICE"],
        has_brts_corridor=True,
    ),
    "NODE_3_BOARD_OFFICE": IntersectionNode(
        node_id="NODE_3_BOARD_OFFICE",
        name="Board Office Square (DB City Mall Arterial)",
        latitude=23.2323,
        longitude=77.4320,
        description="Core commercial bottleneck; highest traffic volume in Bhopal.",
        connected_nodes=["NODE_2_RKMP", "NODE_4_JYOTI_TALKIES"],
        has_brts_corridor=True,
    ),
    "NODE_4_JYOTI_TALKIES": IntersectionNode(
        node_id="NODE_4_JYOTI_TALKIES",
        name="Jyoti Talkies Square (MP Nagar Zone-1)",
        latitude=23.2365,
        longitude=77.4338,
        description="Commercial coaching hub, high turning ratio and feeder flow.",
        connected_nodes=["NODE_3_BOARD_OFFICE", "NODE_5_ROSHANPURA"],
        has_brts_corridor=False,
    ),
    "NODE_5_ROSHANPURA": IntersectionNode(
        node_id="NODE_5_ROSHANPURA",
        name="Roshanpura Square (New Market & Raj Bhavan Link)",
        latitude=23.2427,
        longitude=77.4042,
        description="Dense shopping district with heavy pedestrian crossings and VIP route.",
        connected_nodes=["NODE_4_JYOTI_TALKIES"],
        has_pedestrian_crosswalk=True,
        has_brts_corridor=False,
    )
}

# Vehicle Categories & Heterogeneous Passenger Factors (Indian Context)
VEHICLE_WEIGHTS = {
    "TWO_WHEELER": {"pcu": 0.5, "avg_occupancy": 1.4, "emission_factor": 0.6},
    "AUTO_RICKSHAW": {"pcu": 1.0, "avg_occupancy": 3.2, "emission_factor": 1.1},
    "CAR": {"pcu": 1.0, "avg_occupancy": 1.5, "emission_factor": 1.8},
    "BUS_CHALO": {"pcu": 3.0, "avg_occupancy": 52.0, "emission_factor": 4.5},  # Transit Signal Priority
    "EMERGENCY_AMBULANCE": {"pcu": 1.5, "avg_occupancy": 3.0, "emission_factor": 2.0}
}
