"""
Segment 4: V2X & GLOSA (Green Light Optimal Speed Advisory)
Persona: Ankit Malviya (Daily Commuter, Hoshangabad Rd to MP Nagar)

Solves:
Aggressive acceleration followed by abrupt braking at red lights, fuel waste, and rear-end accidents.
"""

from typing import Dict, Optional

class GLOSAService:
    """
    Computes optimal advisory speeds for connected vehicles approaching Bhopal signals.
    """
    def __init__(self, node_id: str, node_name: str):
        self.node_id = node_id
        self.node_name = node_name

    def compute_speed_advisory(
        self,
        distance_meters: float,
        current_speed_kmh: float,
        is_green: bool,
        time_to_next_phase_sec: float
    ) -> Dict[str, any]:
        """
        Advises the driver whether to coast, decelerate, or maintain speed to pass green smoothly.
        """
        current_speed_mps = current_speed_kmh / 3.6

        if is_green:
            time_needed = distance_meters / max(current_speed_mps, 0.1)
            if time_needed <= time_to_next_phase_sec:
                return {
                    "advisory_speed_kmh": round(current_speed_kmh, 1),
                    "action": "MAINTAIN_SPEED",
                    "guidance": f"Keep {current_speed_kmh:.0f} km/h - green will hold for {time_to_next_phase_sec:.0f}s."
                }
            else:
                # Green will end before reaching; advise smooth deceleration
                return {
                    "advisory_speed_kmh": 20.0,
                    "action": "COAST_TO_STOP",
                    "guidance": f"Phase ending in {time_to_next_phase_sec:.0f}s. Coast smoothly to prevent hard braking."
                }
        else:
            # Currently RED
            time_until_green = time_to_next_phase_sec
            if time_until_green > 0:
                target_speed_mps = distance_meters / time_until_green
                target_speed_kmh = target_speed_mps * 3.6
                target_speed_kmh = min(max(target_speed_kmh, 20.0), 50.0) # Safe speed envelope

                return {
                    "advisory_speed_kmh": round(target_speed_kmh, 1),
                    "action": "GLOSA_CRUISE",
                    "guidance": f"Adjust speed to {target_speed_kmh:.0f} km/h to arrive exactly as signal turns GREEN."
                }

        return {
            "advisory_speed_kmh": round(current_speed_kmh, 1),
            "action": "DEFAULT",
            "guidance": "Drive with normal caution."
        }
