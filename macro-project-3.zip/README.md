# 📈 Hybrid ML-DL Framework for Time-Series Stock Market Trend Prediction and Technical Analysis

A production-grade, mathematically principled quantitative trading framework combining **Deep Learning temporal sequence models** (Bidirectional LSTM with Multi-Head Attention, TCN-Transformer) and **Gradient Boosted Tree Ensembles** (XGBoost, LightGBM, Random Forest) with an **Adaptive Stacking & Feature Fusion Meta-Learner**, a comprehensive **Technical Analysis & Candlestick Pattern Engine**, and a **Realistic Event-Driven Backtesting Simulator**.

---

## 🏗️ System Architecture

```mermaid
flowchart TD
    subgraph Ingestion["1. Data Ingestion & Synthesis Layer"]
        A[Live Yahoo Finance API / Cache] --> C[Standardized OHLCV Series]
        B[Stochastic Regime Jump-Diffusion Generator] --> C
    end

    subgraph FeatureEng["2. Technical Analysis & Morphology Engine"]
        C --> D1[Trend Indicators: SMA, EMA, MACD, SuperTrend, ADX]
        C --> D2[Momentum: Wilder RSI, Stochastic, CCI, Williams %R, MFI]
        C --> D3[Volatility: Bollinger Bands, ATR, Garman-Klass Vol]
        C --> D4[Volume & Money Flow: OBV, CMF, Rolling VWAP]
        C --> D5[Candlestick Patterns: Engulfing, Hammer, Doji, Marubozu]
        D1 & D2 & D3 & D4 & D5 --> E[Multi-Modal Feature Matrix & Consensus Signals]
    end

    subgraph Preprocessing["3. Leakage-Free Temporal Partitioning"]
        E --> F[Forward Return & Trend Formulation]
        F --> G[Walk-Forward Chronological Train / Val / Test Split]
        G --> H1[3D Temporal Tensors: (Batch, Lookback, Features)]
        G --> H2[2D Tabular Feature Matrix: (Batch, Features)]
    end

    subgraph Models["4. Hybrid ML-DL Synthesis Layer"]
        H1 --> DL1[BiLSTM + Bahdanau Temporal Attention]
        H1 --> DL2[TCN + Positional Transformer Encoder]
        H2 --> ML1[XGBoost Classifier]
        H2 --> ML2[LightGBM Classifier]
        H2 --> ML3[Random Forest Classifier]
        
        DL1 -- "Latent Embeddings (h_t)" --> FF[Deep Feature Fusion: Tabular + DL Latent]
        FF --> ML_Fused[Feature-Fused Gradient Boosted Model]

        DL1 -- "Probabilities" --> Meta[Stacking Ensemble Meta-Learner]
        ML1 -- "Probabilities" --> Meta
        ML2 -- "Probabilities" --> Meta
        ML3 -- "Probabilities" --> Meta
        
        Meta --> Ens[Adaptive Confidence Consensus Predictor]
        ML_Fused --> Ens
    end

    subgraph Evaluation["5. Backtesting & Explainability"]
        Ens --> BT[Vectorized Backtest Engine with Commission & Slippage]
        Ens --> XAI[Explainable AI: Attention Profiles & Feature Attribution]
        BT --> DASH[Interactive Streamlit Dashboard & Plotly Financial Charts]
        XAI --> DASH
    end
```

---

## 🧮 Mathematical Formulations

### 1. Target Trend Labeling (Zero Lookahead Bias)
For a lookahead horizon $k \ge 1$ and classification deadband threshold $\tau \ge 0$:
$$R_{t, t+k} = \frac{\text{Close}_{t+k}}{\text{Close}_t} - 1.0$$
$$y_t = \begin{cases} 1 & \text{if } R_{t, t+k} > \tau \quad (\text{Bullish Uptrend}) \\ 0 & \text{if } R_{t, t+k} \le \tau \quad (\text{Bearish / Neutral Drift}) \end{cases}$$

### 2. Bahdanau Temporal Self-Attention Mechanism
Given input sequence $X = (x_{t-W+1}, \dots, x_t)$, the bidirectional LSTM yields hidden states $h_i \in \mathbb{R}^{2 \cdot d_{hidden}}$. The temporal attention score $\alpha_i$ determines the predictive relevance of each historical day $i$:
$$u_i = \tanh\left(W_s h_i + b_s\right)$$
$$\alpha_i = \frac{\exp(u_i^\top v)}{\sum_{j=1}^W \exp(u_j^\top v)}, \quad \sum_{i=1}^W \alpha_i = 1$$
$$c_t = \sum_{i=1}^W \alpha_i h_i$$
Where $c_t$ is the context vector fed into the deep latent projection layer.

### 3. Stacking Ensemble Meta-Learner
Let $\hat{p}_{DL}, \hat{p}_{XGB}, \hat{p}_{LGB}, \hat{p}_{RF} \in [0, 1]$ represent out-of-fold probabilistic predictions of the individual base models. The Meta-Learner is calibrated via regularized logistic regression:
$$\hat{p}_{stack} = \sigma\left(w_0 + w_1 \hat{p}_{DL} + w_2 \hat{p}_{XGB} + w_3 \hat{p}_{LGB} + w_4 \hat{p}_{RF}\right)$$
Subject to $L_2$ regularization $\min_{w} \mathcal{L}(w) + \frac{\lambda}{2} \|w\|_2^2$.

### 4. Deep Latent Feature Fusion
The DL network acts as a deep non-linear temporal representation learner:
$$e_t = \text{LatentEncoder}\left(X_{t-W+1 : t}\right) \in \mathbb{R}^{32}$$
The enriched feature vector concatenates the tabular technical indicators $x_t \in \mathbb{R}^F$ with the deep sequential latent vector:
$$x_t^{\text{fused}} = \left[ x_t \;\Vert\; e_t \right] \in \mathbb{R}^{F + 32}$$
Fed directly into second-stage Gradient Boosted Decision Trees.

### 5. Quantitative Risk & Portfolio Metrics
- **Annualized Sharpe Ratio**:
  $$\text{Sharpe} = \frac{\mathbb{E}[R_p - R_f]}{\sigma(R_p - R_f)} \cdot \sqrt{252}$$
- **Sortino Ratio** (downside risk only):
  $$\text{Sortino} = \frac{\mathbb{E}[R_p - R_f]}{\sqrt{\frac{1}{N} \sum \min(0, R_p - R_f)^2}} \cdot \sqrt{252}$$
- **Maximum Drawdown (MDD)**:
  $$\text{MDD} = \min_{t} \left( \frac{V_t - \max_{s \le t} V_s}{\max_{s \le t} V_s} \right)$$
- **Value at Risk (VaR 95%)**:
  $$\text{VaR}_{0.95} = \inf \{ l \in \mathbb{R} : P(L > l) \le 0.05 \}$$

---

## 📂 Project Structure

```
.
├── config.py                  # Global hyperparameters & configuration dataclasses
├── main.py                    # Production CLI runner for training, predicting, backtesting
├── requirements.txt           # Dependency specifications
├── README.md                  # Complete architectural & mathematical documentation
│
├── data/
│   ├── loader.py              # yfinance ingestion + local CSV caching + synthetic market generator
│   ├── preprocessor.py        # Outlier handling, leak-free scalers, chronological walk-forward split
│   └── sequence_builder.py    # 3D sliding window tensors (DL) & 2D tabular feature builder (ML)
│
├── indicators/
│   ├── technical.py           # Pure NumPy/Pandas vectorized indicators (SMA, EMA, MACD, RSI, BB, etc.)
│   ├── patterns.py            # Candlestick pattern detection (Doji, Hammer, Engulfing, Marubozu)
│   └── signal_generator.py    # Discrete rule-based trading signals & consensus rating
│
├── models/
│   ├── dl_models.py           # PyTorch BiLSTM+Attention, TCN-Transformer & DeepLearningTrainer
│   ├── ml_models.py           # XGBoost, LightGBM, and Random Forest wrappers
│   └── hybrid_framework.py    # Stacking Meta-Learner, Feature Fusion, Adaptive Blending
│
├── backtesting/
│   ├── engine.py              # Event-driven/Vectorized backtester with commission & slippage
│   └── metrics.py             # Quantitative financial metrics (Sharpe, Sortino, Calmar, MDD, VaR)
│
├── explainability/
│   └── interpreter.py         # Feature importances, attention profile heatmap, decision explanations
│
├── visualization/
│   └── plots.py               # Interactive Plotly candlestick, indicator panels, and equity charts
│
├── app/
│   └── dashboard.py           # Interactive Streamlit Web Dashboard
│
└── tests/
    ├── test_indicators.py     # Unit tests for technical indicator engine and candlestick patterns
    ├── test_pipeline.py       # Integration tests for data pipeline and sequence builders
    └── test_hybrid.py         # End-to-end tests for hybrid models and backtesting engine
```

---

## ⚡ Quickstart Guide

### 1. Installation
Ensure Python 3.10+ is available. Install dependencies:
```bash
pip install -r requirements.txt
```

### 2. Run Command Line Interface (CLI)
Train the hybrid models and backtest a stock (e.g. Apple Inc. `AAPL`):
```bash
python main.py --ticker AAPL --start 2021-01-01 --dl_model bilstm_attention --lookback 30 --epochs 25 --threshold 0.55
```

Or test on high-beta growth stocks or indices:
```bash
python main.py --ticker NVDA --start 2021-01-01
python main.py --ticker SPY --start 2020-01-01
```

### 3. Launch Interactive Web Dashboard
Run the modern Streamlit dashboard for interactive charting, model benchmarking, and visual backtesting:
```bash
streamlit run app/dashboard.py
```

Features in the Dashboard:
1. **Interactive Candlestick Chart**: Multi-panel Plotly chart with Bollinger Bands, Moving Averages, SuperTrend, Volume MA, and MACD/RSI.
2. **Indicator Signal Matrix**: Real-time Bullish, Bearish, and Neutral consensus status across 12+ technical metrics.
3. **Model Benchmarking**: Side-by-side comparison of BiLSTM-Attention, XGBoost, LightGBM, Random Forest, Stacking Meta-Learner, and Feature Fusion.
4. **Quantitative Backtest Engine**: Interactive equity curve vs Buy & Hold benchmark with underwater drawdown chart, CAGR, Sharpe, Sortino, Calmar, and VaR.
5. **Explainable AI (XAI)**: Visualizes historical lookback days that triggered the neural attention weights and top feature attribution.

---

## 🧪 Running the Test Suite

Execute comprehensive unit and integration tests:
```bash
pytest tests/ -v
```
