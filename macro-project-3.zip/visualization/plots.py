"""
Interactive Plotly Financial Charting and Model Diagnostics
"""
from typing import Optional, Dict, Any, List
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots


def plot_candlestick_with_indicators(
    df: pd.DataFrame,
    title: str = "Price Action and Technical Indicators",
    show_signals: bool = True
) -> go.Figure:
    """
    Creates an interactive 3-panel financial chart:
    Panel 1: Candlesticks + Bollinger Bands + Moving Averages + SuperTrend
    Panel 2: Volume with MA
    Panel 3: MACD and RSI
    """
    fig = make_subplots(
        rows=3, cols=1,
        shared_xaxes=True,
        vertical_spacing=0.03,
        row_heights=[0.60, 0.20, 0.20],
        subplot_titles=(title, "Volume", "MACD & RSI (14)")
    )

    # 1. Main Candlestick Chart
    fig.add_trace(
        go.Candlestick(
            x=df.index,
            open=df['Open'],
            high=df['High'],
            low=df['Low'],
            close=df['Close'],
            name="OHLC",
            increasing_line_color="#26a69a",
            decreasing_line_color="#ef5350"
        ),
        row=1, col=1
    )

    # Overlays: Moving Averages
    if 'SMA_20' in df.columns:
        fig.add_trace(go.Scatter(x=df.index, y=df['SMA_20'], line=dict(color='#ff9800', width=1.2), name="SMA 20"), row=1, col=1)
    if 'SMA_50' in df.columns:
        fig.add_trace(go.Scatter(x=df.index, y=df['SMA_50'], line=dict(color='#2196f3', width=1.2), name="SMA 50"), row=1, col=1)
    if 'EMA_21' in df.columns:
        fig.add_trace(go.Scatter(x=df.index, y=df['EMA_21'], line=dict(color='#9c27b0', width=1.0, dash='dot'), name="EMA 21"), row=1, col=1)

    # Overlays: Bollinger Bands
    if 'BB_Upper' in df.columns and 'BB_Lower' in df.columns:
        fig.add_trace(go.Scatter(x=df.index, y=df['BB_Upper'], line=dict(color='rgba(150, 150, 150, 0.4)', width=1), name="BB Upper"), row=1, col=1)
        fig.add_trace(go.Scatter(x=df.index, y=df['BB_Lower'], line=dict(color='rgba(150, 150, 150, 0.4)', width=1), fill='tonexty', fillcolor='rgba(200, 200, 200, 0.1)', name="BB Lower"), row=1, col=1)

    # Overlays: SuperTrend
    if 'SuperTrend' in df.columns:
        fig.add_trace(go.Scatter(x=df.index, y=df['SuperTrend'], line=dict(color='#00e676', width=1.2), name="SuperTrend"), row=1, col=1)

    # Optional Buy / Sell Signals markers
    if show_signals and 'Signal' in df.columns:
        buy_points = df[df['Signal'] > 0]
        sell_points = df[df['Signal'] < 0]
        if not buy_points.empty:
            fig.add_trace(go.Scatter(
                x=buy_points.index, y=buy_points['Low'] * 0.985,
                mode='markers', marker=dict(symbol='triangle-up', size=11, color='#00e676'),
                name="Buy Signal"
            ), row=1, col=1)
        if not sell_points.empty:
            fig.add_trace(go.Scatter(
                x=sell_points.index, y=sell_points['High'] * 1.015,
                mode='markers', marker=dict(symbol='triangle-down', size=11, color='#ff1744'),
                name="Sell Signal"
            ), row=1, col=1)

    # 2. Volume Panel
    vol_colors = np.where(df['Close'] >= df['Open'], 'rgba(38, 166, 154, 0.7)', 'rgba(239, 83, 80, 0.7)')
    fig.add_trace(
        go.Bar(x=df.index, y=df['Volume'], marker_color=vol_colors, name="Volume"),
        row=2, col=1
    )
    if 'Volume' in df.columns:
        vol_ma = df['Volume'].rolling(20).mean()
        fig.add_trace(go.Scatter(x=df.index, y=vol_ma, line=dict(color='#ffeb3b', width=1), name="Vol MA 20"), row=2, col=1)

    # 3. MACD Panel
    if 'MACD' in df.columns and 'MACD_Signal' in df.columns:
        fig.add_trace(go.Scatter(x=df.index, y=df['MACD'], line=dict(color='#29b6f6', width=1.2), name="MACD"), row=3, col=1)
        fig.add_trace(go.Scatter(x=df.index, y=df['MACD_Signal'], line=dict(color='#ff7043', width=1.2), name="Signal"), row=3, col=1)
        if 'MACD_Hist' in df.columns:
            hist_colors = np.where(df['MACD_Hist'] >= 0, '#66bb6a', '#ef5350')
            fig.add_trace(go.Bar(x=df.index, y=df['MACD_Hist'], marker_color=hist_colors, name="MACD Hist"), row=3, col=1)

    fig.update_layout(
        template="plotly_dark",
        xaxis_rangeslider_visible=False,
        height=850,
        margin=dict(l=40, r=40, t=50, b=40),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )
    return fig


def plot_equity_curve(
    history_df: pd.DataFrame,
    metrics: Dict[str, Any],
    title: str = "Quantitative Strategy Backtest vs Buy & Hold"
) -> go.Figure:
    """
    Plots cumulative portfolio value, benchmark curve, and underwater drawdown.
    """
    fig = make_subplots(
        rows=2, cols=1,
        shared_xaxes=True,
        vertical_spacing=0.04,
        row_heights=[0.75, 0.25],
        subplot_titles=(title, "Underwater Drawdown (%)")
    )

    # Portfolio Equity
    fig.add_trace(
        go.Scatter(
            x=history_df.index,
            y=history_df['Equity'],
            mode='lines',
            line=dict(color='#00e676', width=2),
            name="Hybrid Strategy Equity"
        ),
        row=1, col=1
    )

    # Benchmark
    if 'Benchmark_Equity' in history_df.columns:
        fig.add_trace(
            go.Scatter(
                x=history_df.index,
                y=history_df['Benchmark_Equity'],
                mode='lines',
                line=dict(color='#90caf9', width=1.5, dash='dash'),
                name="Buy & Hold Benchmark"
            ),
            row=1, col=1
        )

    # Underwater Drawdown
    equity = history_df['Equity']
    running_max = equity.cummax()
    dd = (equity - running_max) / running_max * 100.0

    fig.add_trace(
        go.Scatter(
            x=history_df.index,
            y=dd,
            mode='lines',
            line=dict(color='#ff5252', width=1),
            fill='tozeroy',
            fillcolor='rgba(255, 82, 82, 0.2)',
            name="Drawdown %"
        ),
        row=2, col=1
    )

    fig.update_layout(
        template="plotly_dark",
        height=650,
        margin=dict(l=40, r=40, t=50, b=40),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )
    return fig


def plot_model_comparison(metrics_df: pd.DataFrame) -> go.Figure:
    """
    Renders bar chart comparing performance metrics across ML, DL, and Hybrid frameworks.
    """
    fig = go.Figure()

    metrics = ['Accuracy', 'Precision', 'Recall', 'F1 Score', 'ROC-AUC']
    colors = ['#42a5f5', '#66bb6a', '#ffa726', '#ab47bc', '#26c6da']

    for m, c in zip(metrics, colors):
        if m in metrics_df.columns:
            fig.add_trace(go.Bar(
                name=m,
                x=metrics_df['Model'],
                y=metrics_df[m],
                marker_color=c
            ))

    fig.update_layout(
        barmode='group',
        template="plotly_dark",
        title="Predictive Performance Comparison: ML vs DL vs Hybrid Architecture",
        yaxis_title="Metric Score",
        height=480,
        margin=dict(l=40, r=40, t=50, b=40),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )
    return fig


def plot_attention_heatmap(attn_weights: np.ndarray, title: str = "BiLSTM Temporal Attention Profile") -> go.Figure:
    """
    Visualizes attention weights over the historical lookback days.
    """
    # Average across samples if 2D
    if attn_weights.ndim == 2:
        avg_attn = attn_weights.mean(axis=0)
    else:
        avg_attn = attn_weights

    lookback = len(avg_attn)
    days = [f"t-{lookback - 1 - i}" if i < lookback - 1 else "t (Today)" for i in range(lookback)]

    fig = go.Figure(data=go.Bar(
        x=days,
        y=avg_attn,
        marker=dict(
            color=avg_attn,
            colorscale='Viridis',
            showscale=True
        )
    ))

    fig.update_layout(
        title=title,
        template="plotly_dark",
        xaxis_title="Historical Lookback Days",
        yaxis_title="Attention Weight",
        height=400,
        margin=dict(l=40, r=40, t=50, b=40)
    )
    return fig


def plot_feature_importance(imp_df: pd.DataFrame, title: str = "Top Technical Indicator Importances") -> go.Figure:
    """
    Renders horizontal bar chart of top predictor indicators.
    """
    sorted_df = imp_df.sort_values('Composite_Importance', ascending=True)

    fig = go.Figure(go.Bar(
        x=sorted_df['Composite_Importance'],
        y=sorted_df.index,
        orientation='h',
        marker=dict(color='#26a69a')
    ))

    fig.update_layout(
        title=title,
        template="plotly_dark",
        xaxis_title="Importance Score",
        yaxis_title="Technical Indicator",
        height=480,
        margin=dict(l=100, r=40, t=50, b=40)
    )
    return fig
