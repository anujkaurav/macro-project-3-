"""
Quantitative Financial Performance and Risk Metrics Engine
Calculates Sharpe, Sortino, Calmar, Max Drawdown, VaR, and Profit Factor.
"""
from typing import Dict, Any
import numpy as np
import pandas as pd


class FinancialMetricsCalculator:
    """
    Computes professional quantitative performance metrics for equity curves and trading signals.
    """

    @staticmethod
    def calculate_all(
        equity_curve: pd.Series,
        benchmark_curve: Optional[pd.Series] = None,
        trade_returns: Optional[pd.Series] = None,
        risk_free_rate: float = 0.02
    ) -> Dict[str, Any]:
        """
        Takes cumulative portfolio equity series and computes standardized metrics.
        """
        if equity_curve.empty or len(equity_curve) < 2:
            return {}

        daily_returns = equity_curve.pct_change().dropna()
        n_days = len(daily_returns)
        years = max(n_days / 252.0, 1.0 / 252.0)

        # 1. Total & Annualized Returns
        total_return = (equity_curve.iloc[-1] / equity_curve.iloc[0]) - 1.0
        cagr = (equity_curve.iloc[-1] / equity_curve.iloc[0]) ** (1.0 / years) - 1.0

        # 2. Volatility
        daily_vol = daily_returns.std()
        ann_vol = daily_vol * np.sqrt(252) if daily_vol > 0 else 1e-6

        # 3. Sharpe Ratio
        rf_daily = (1.0 + risk_free_rate) ** (1.0 / 252.0) - 1.0
        excess_returns = daily_returns - rf_daily
        sharpe = (excess_returns.mean() / daily_vol) * np.sqrt(252) if daily_vol > 0 else 0.0

        # 4. Sortino Ratio (downside deviation only)
        downside_returns = daily_returns[daily_returns < 0]
        downside_std = downside_returns.std() * np.sqrt(252)
        sortino = (excess_returns.mean() * 252) / downside_std if (downside_std and downside_std > 0) else 0.0

        # 5. Drawdown Analytics
        running_max = equity_curve.cummax()
        drawdowns = (equity_curve - running_max) / running_max
        max_drawdown = drawdowns.min()  # Negative value

        # Calmar Ratio
        calmar = cagr / abs(max_drawdown) if abs(max_drawdown) > 0 else 0.0

        # 6. Risk metrics: Value at Risk (VaR 95%) & Conditional VaR (CVaR 95%)
        var_95 = np.percentile(daily_returns, 5) if len(daily_returns) > 20 else 0.0
        cvar_95 = daily_returns[daily_returns <= var_95].mean() if len(daily_returns) > 20 else 0.0

        # 7. Trade-level statistics
        win_rate = 0.0
        profit_factor = 0.0
        num_trades = 0
        if trade_returns is not None and not trade_returns.empty:
            num_trades = len(trade_returns)
            wins = trade_returns[trade_returns > 0]
            losses = trade_returns[trade_returns < 0]
            win_rate = len(wins) / num_trades if num_trades > 0 else 0.0
            gross_profit = wins.sum()
            gross_loss = abs(losses.sum())
            profit_factor = gross_profit / gross_loss if gross_loss > 0 else (gross_profit if gross_profit > 0 else 1.0)

        # 8. Benchmark comparisons (e.g. Buy and Hold)
        bench_return = None
        bench_sharpe = None
        if benchmark_curve is not None and not benchmark_curve.empty:
            bench_return = (benchmark_curve.iloc[-1] / benchmark_curve.iloc[0]) - 1.0
            bench_daily_ret = benchmark_curve.pct_change().dropna()
            bench_vol = bench_daily_ret.std() * np.sqrt(252)
            bench_sharpe = ((bench_daily_ret.mean() - rf_daily) / bench_daily_ret.std()) * np.sqrt(252) if bench_vol > 0 else 0.0

        return {
            'Initial Capital': round(float(equity_curve.iloc[0]), 2),
            'Final Capital': round(float(equity_curve.iloc[-1]), 2),
            'Total Return (%)': round(float(total_return * 100), 2),
            'CAGR (%)': round(float(cagr * 100), 2),
            'Annualized Volatility (%)': round(float(ann_vol * 100), 2),
            'Sharpe Ratio': round(float(sharpe), 2),
            'Sortino Ratio': round(float(sortino), 2),
            'Calmar Ratio': round(float(calmar), 2),
            'Max Drawdown (%)': round(float(max_drawdown * 100), 2),
            'Daily VaR 95% (%)': round(float(var_95 * 100), 2),
            'Daily CVaR 95% (%)': round(float(cvar_95 * 100), 2),
            'Win Rate (%)': round(float(win_rate * 100), 2),
            'Profit Factor': round(float(profit_factor), 2),
            'Total Trades': int(num_trades),
            'Benchmark Return (%)': round(float(bench_return * 100), 2) if bench_return is not None else None,
            'Benchmark Sharpe': round(float(bench_sharpe), 2) if bench_sharpe is not None else None,
        }
