"""
Quantitative Backtesting and Execution Simulation Engine
Simulates realistic trading with transaction costs, slippage, and position sizing.
"""
from typing import Dict, Any, Optional, Tuple
import numpy as np
import pandas as pd
from config import BacktestConfig
from .metrics import FinancialMetricsCalculator


class BacktestEngine:
    """
    Simulates trading strategies driven by model probability forecasts and technical indicators.
    """

    def __init__(self, config: Optional[BacktestConfig] = None):
        self.cfg = config or BacktestConfig()

    def run_backtest(
        self,
        price_df: pd.DataFrame,
        probabilities: np.ndarray,
        dates: pd.Index,
        allow_short: bool = False
    ) -> Tuple[pd.DataFrame, Dict[str, Any]]:
        """
        Executes backtest over dates aligned with probabilities.

        Args:
            price_df: Full OHLCV DataFrame
            probabilities: Model predicted probabilities P(Up) in [0, 1]
            dates: DatetimeIndex corresponding to probabilities
            allow_short: If True, takes short positions when P(Up) < (1 - threshold)

        Returns:
            history_df: Daily portfolio valuation, positions, and equity curve
            metrics: Standardized financial performance dictionary
        """
        # Subset price data to test window
        sub_df = price_df.loc[dates].copy()
        sub_df['Prob_Up'] = probabilities

        # Signal Generation with Deadband Confidence Threshold
        # E.g. Buy if Prob > 0.55; Sell/Short if Prob < 0.45; otherwise Flat/Hold cash
        thresh_up = self.cfg.confidence_threshold
        thresh_down = 1.0 - thresh_up

        signals = np.zeros(len(sub_df))
        for i, p in enumerate(probabilities):
            if p >= thresh_up:
                signals[i] = 1.0
            elif allow_short and (p <= thresh_down):
                signals[i] = -1.0
            else:
                signals[i] = 0.0

        sub_df['Signal'] = signals

        # Position execution: Signal at close of t affects position during t+1
        # Shifting signal by 1 models next-day execution without lookahead!
        sub_df['Target_Position'] = sub_df['Signal'].shift(1).fillna(0.0)

        # Simulation variables
        initial_cash = self.cfg.initial_capital
        cash = initial_cash
        shares = 0.0
        equity_records = []
        trade_returns = []

        entry_price = 0.0
        entry_idx = None
        current_pos = 0.0

        close_prices = sub_df['Close'].values
        target_positions = sub_df['Target_Position'].values
        d_indices = sub_df.index

        for i in range(len(sub_df)):
            curr_price = close_prices[i]
            target_pos = target_positions[i]

            # Check if position changes
            if target_pos != current_pos:
                # 1. Close existing position if any
                if current_pos != 0:
                    exit_price = curr_price * (1.0 - self.cfg.slippage if current_pos > 0 else 1.0 + self.cfg.slippage)
                    gross_val = shares * exit_price
                    comm = abs(gross_val) * self.cfg.commission_rate
                    net_val = gross_val - comm
                    cash += net_val

                    # Record trade PnL
                    trade_ret = (exit_price / entry_price - 1.0) * np.sign(current_pos)
                    trade_returns.append(trade_ret)

                    shares = 0.0
                    current_pos = 0.0

                # 2. Open new position if target_pos != 0
                if target_pos != 0:
                    curr_equity = cash
                    alloc_capital = curr_equity * self.cfg.risk_fraction
                    entry_price = curr_price * (1.0 + self.cfg.slippage if target_pos > 0 else 1.0 - self.cfg.slippage)

                    # Number of shares
                    shares = (alloc_capital / entry_price) * target_pos
                    gross_val = abs(shares * entry_price)
                    comm = gross_val * self.cfg.commission_rate
                    cash -= (shares * entry_price + comm)
                    current_pos = target_pos
                    entry_idx = d_indices[i]

            # Mark to Market
            total_equity = cash + (shares * curr_price)
            equity_records.append(total_equity)

        sub_df['Equity'] = equity_records

        # Benchmark: Buy & Hold
        bench_initial_price = close_prices[0]
        sub_df['Benchmark_Equity'] = (close_prices / bench_initial_price) * initial_cash

        # Calculate metrics
        metrics = FinancialMetricsCalculator.calculate_all(
            equity_curve=sub_df['Equity'],
            benchmark_curve=sub_df['Benchmark_Equity'],
            trade_returns=pd.Series(trade_returns) if trade_returns else pd.Series(dtype=float)
        )

        return sub_df, metrics
