@echo off
title Hybrid ML-DL Stock Market Trend Prediction - CLI Demo
color 0B
echo ===============================================================================
echo   HYBRID ML-DL STOCK MARKET TREND PREDICTION & TECHNICAL ANALYSIS
echo   Executing Command-Line Model Benchmark & Quantitative Backtest
echo ===============================================================================
echo.

cd /d "%~dp0"

if exist "C:\ProgramData\anaconda3\python.exe" (
    set "PYTHON_EXE=C:\ProgramData\anaconda3\python.exe"
) else (
    set "PYTHON_EXE=python"
)

echo Running CLI Presentation Demo on Apple Inc. (AAPL)...
echo.
"%PYTHON_EXE%" run_demo.py AAPL

echo.
echo ===============================================================================
echo   Execution Finished. Press any key to close this terminal.
echo ===============================================================================
pause
