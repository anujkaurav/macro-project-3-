"""
End-to-End Test for Hybrid Model Training and Quantitative Backtest Engine
"""
import pytest
import numpy as np
import pandas as pd
from data.loader import SyntheticMarketGenerator
from indicators.technical import TechnicalIndicatorEngine
from indicators.patterns import CandlestickPatternDetector
from indicators.signal_generator import TechnicalSignalGenerator
from data.preprocessor import MarketDataPreprocessor
from data.sequence_builder import TimeSeriesSequenceBuilder
from models.hybrid_framework import HybridFramework
from backtesting.engine import BacktestEngine
from config import ModelConfig, BacktestConfig


def test_end_to_end_hybrid_framework():
    # 1. Generate Synthetic Data
    df_raw = SyntheticMarketGenerator.generate("SYNTH", "2021-01-01", "2023-01-01", seed=99)
    ind_engine = TechnicalIndicatorEngine()
    df_ind = ind_engine.compute_all(df_raw)
    df_patt = CandlestickPatternDetector.detect_all(df_ind)
    df_full = TechnicalSignalGenerator.generate_signals(df_patt)

    # 2. Preprocess & Sequence
    cfg = ModelConfig(
        lookback_window=10,
        dl_epochs=5,
        dl_batch_size=16,
        xgb_n_estimators=10,
        lgb_n_estimators=10,
        rf_n_estimators=10
    )
    preprocessor = MarketDataPreprocessor(cfg)
    features_df, target_clf, _ = preprocessor.prepare_dataset(df_full)
    splits = preprocessor.split_chronological(features_df, target_clf)

    X_train_df, y_train_s = splits['train']
    X_val_df, y_val_s = splits['val']
    X_test_df, y_test_s = splits['test']

    builder = TimeSeriesSequenceBuilder(lookback_window=cfg.lookback_window)
    X_seq_train, X_tab_train, y_train, _ = builder.build_sequences(X_train_df, y_train_s)
    X_seq_val, X_tab_val, y_val, _ = builder.build_sequences(X_val_df, y_val_s)
    X_seq_test, X_tab_test, y_test, dates_test = builder.build_sequences(X_test_df, y_test_s)

    # 3. Train Hybrid
    hybrid = HybridFramework(cfg)
    hybrid.train(
        X_seq_train, X_tab_train, y_train,
        X_seq_val, X_tab_val, y_val
    )

    # 4. Predict
    all_preds = hybrid.predict_all_models(X_seq_test, X_tab_test)
    assert 'Hybrid (Full Framework)' in all_preds
    hybrid_probs = all_preds['Hybrid (Full Framework)']
    assert len(hybrid_probs) == len(X_seq_test)
    assert (hybrid_probs >= 0.0).all() and (hybrid_probs <= 1.0).all()

    # 5. Evaluate
    eval_df = hybrid.evaluate(X_seq_test, X_tab_test, y_test)
    assert not eval_df.empty
    assert 'F1 Score' in eval_df.columns

    # 6. Backtest
    bt_cfg = BacktestConfig(confidence_threshold=0.52)
    engine = BacktestEngine(bt_cfg)
    history, metrics = engine.run_backtest(df_full, hybrid_probs, dates_test)

    assert 'Total Return (%)' in metrics
    assert 'Sharpe Ratio' in metrics
    assert 'Max Drawdown (%)' in metrics
    assert len(history) == len(dates_test)
