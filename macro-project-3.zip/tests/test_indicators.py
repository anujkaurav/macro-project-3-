"""
Unit Tests for Technical Indicator Engine and Candlestick Pattern Detection
"""
import pytest
import numpy as np
import pandas as pd
from data.loader import SyntheticMarketGenerator
from indicators.technical import TechnicalIndicatorEngine
from indicators.patterns import CandlestickPatternDetector
from indicators.signal_generator import TechnicalSignalGenerator


@pytest.fixture
def sample_market_data():
    return SyntheticMarketGenerator.generate(
        ticker="TEST_TICKER",
        start_date="2022-01-01",
        end_date="2023-01-01",
        initial_price=100.0,
        seed=123
    )


def test_technical_indicator_engine(sample_market_data):
    engine = TechnicalIndicatorEngine()
    df_ind = engine.compute_all(sample_market_data)

    # Check key columns exist
    expected_cols = [
        'SMA_20', 'SMA_50', 'EMA_21', 'MACD', 'MACD_Signal', 'MACD_Hist',
        'RSI', 'BB_Upper', 'BB_Lower', 'BB_PercentB', 'ATR', 'Stoch_K',
        'Stoch_D', 'CCI', 'Williams_R', 'MFI', 'Plus_DI', 'Minus_DI',
        'ADX', 'SuperTrend', 'OBV', 'CMF', 'VWAP_20'
    ]
    for col in expected_cols:
        assert col in df_ind.columns, f"Missing indicator column: {col}"

    # Check mathematical ranges
    clean_rsi = df_ind['RSI'].dropna()
    assert (clean_rsi >= 0.0).all() and (clean_rsi <= 100.0).all(), "RSI out of bounds [0, 100]"

    clean_stoch = df_ind['Stoch_K'].dropna()
    assert (clean_stoch >= -1e-5).all() and (clean_stoch <= 100.0 + 1e-5).all(), "Stoch K out of bounds"

    clean_bb = df_ind.dropna(subset=['BB_Upper', 'BB_Lower'])
    assert (clean_bb['BB_Upper'] >= clean_bb['BB_Lower']).all(), "BB Upper must be >= BB Lower"


def test_candlestick_patterns(sample_market_data):
    df_patt = CandlestickPatternDetector.detect_all(sample_market_data)

    patt_cols = [
        'Pattern_Doji', 'Pattern_Hammer', 'Pattern_Inverted_Hammer',
        'Pattern_Bullish_Engulfing', 'Pattern_Bearish_Engulfing',
        'Pattern_Composite_Score'
    ]
    for col in patt_cols:
        assert col in df_patt.columns, f"Missing pattern column: {col}"

    # Values must be binary or valid integers
    assert set(df_patt['Pattern_Doji'].unique()).issubset({0, 1})
    assert set(df_patt['Pattern_Hammer'].unique()).issubset({0, 1})


def test_signal_generator(sample_market_data):
    engine = TechnicalIndicatorEngine()
    df_ind = engine.compute_all(sample_market_data)
    df_patt = CandlestickPatternDetector.detect_all(df_ind)
    df_signals = TechnicalSignalGenerator.generate_signals(df_patt)

    assert 'Technical_Consensus_Score' in df_signals.columns
    scores = df_signals['Technical_Consensus_Score'].dropna()
    assert (scores >= -1.0).all() and (scores <= 1.0).all()

    summary = TechnicalSignalGenerator.get_latest_summary(df_signals)
    assert 'consensus_score' in summary
    assert 'rating' in summary
    assert summary['rating'] in ["Strong Buy", "Buy", "Neutral", "Sell", "Strong Sell"]
