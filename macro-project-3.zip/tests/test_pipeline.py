"""
Integration Tests for Data Pipeline and Sequence Builder
"""
import pytest
import numpy as np
import pandas as pd
from data.loader import SyntheticMarketGenerator
from indicators.technical import TechnicalIndicatorEngine
from data.preprocessor import MarketDataPreprocessor
from data.sequence_builder import TimeSeriesSequenceBuilder
from config import ModelConfig


@pytest.fixture
def market_df():
    df = SyntheticMarketGenerator.generate("TEST", "2022-01-01", "2023-06-01", seed=42)
    engine = TechnicalIndicatorEngine()
    return engine.compute_all(df)


def test_preprocessor_and_split(market_df):
    cfg = ModelConfig(train_ratio=0.7, val_ratio=0.15, test_ratio=0.15)
    preprocessor = MarketDataPreprocessor(cfg)
    features, target_clf, target_reg = preprocessor.prepare_dataset(market_df)

    assert len(features) > 100
    assert len(features) == len(target_clf)
    assert set(target_clf.unique()).issubset({0, 1})

    splits = preprocessor.split_chronological(features, target_clf)
    X_train, y_train = splits['train']
    X_val, y_val = splits['val']
    X_test, y_test = splits['test']

    # Chronological alignment
    assert X_train.index.max() < X_val.index.min()
    assert X_val.index.max() < X_test.index.min()


def test_sequence_builder(market_df):
    cfg = ModelConfig(lookback_window=15)
    preprocessor = MarketDataPreprocessor(cfg)
    features, target_clf, _ = preprocessor.prepare_dataset(market_df)

    builder = TimeSeriesSequenceBuilder(lookback_window=15)
    X_seq, X_tab, y, dates = builder.build_sequences(features, target_clf)

    assert X_seq.ndim == 3
    assert X_seq.shape[1] == 15
    assert X_seq.shape[2] == features.shape[1]
    assert X_tab.shape == (len(X_seq), features.shape[1])
    assert len(y) == len(X_seq)
    assert len(dates) == len(X_seq)
