"""
Command Line Interface (CLI) Entry Point for Hybrid ML-DL Stock Market Framework
"""
import argparse
import os
import sys
import datetime
import pandas as pd
import numpy as np

from config import AppConfig, IndicatorConfig, ModelConfig, BacktestConfig
from data.loader import MarketDataLoader
from indicators.technical import TechnicalIndicatorEngine
from indicators.patterns import CandlestickPatternDetector
from indicators.signal_generator import TechnicalSignalGenerator
from data.preprocessor import MarketDataPreprocessor
from data.sequence_builder import TimeSeriesSequenceBuilder
from models.hybrid_framework import HybridFramework
from backtesting.engine import BacktestEngine
from explainability.interpreter import FrameworkInterpreter


if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass


def parse_args():
    parser = argparse.ArgumentParser(
        description="Hybrid ML-DL Framework for Time-Series Stock Market Prediction"
    )
    parser.add_argument("--ticker", type=str, default="AAPL", help="Stock ticker symbol (e.g. AAPL, NVDA, SPY)")
    parser.add_argument("--start", type=str, default="2021-01-01", help="Start date (YYYY-MM-DD)")
    parser.add_argument("--end", type=str, default=None, help="End date (YYYY-MM-DD)")
    parser.add_argument("--dl_model", type=str, default="bilstm_attention", choices=["bilstm_attention", "tcn_transformer"], help="DL Backbone")
    parser.add_argument("--lookback", type=int, default=30, help="Temporal lookback window (days)")
    parser.add_argument("--epochs", type=int, default=25, help="Deep learning training epochs")
    parser.add_argument("--threshold", type=float, default=0.51, help="Backtest confidence threshold")
    parser.add_argument("--allow_short", action="store_true", default=True, help="Allow taking short positions")
    parser.add_argument("--no_cache", action="store_true", help="Bypass local CSV cache")
    return parser.parse_args()


def main():
    args = parse_args()
    end_date = args.end or datetime.date.today().strftime("%Y-%m-%d")

    print("=" * 80)
    print("[*] HYBRID ML-DL STOCK MARKET TREND PREDICTION & TECHNICAL ANALYSIS FRAMEWORK")
    print("=" * 80)
    print(f"Asset Ticker   : {args.ticker}")
    print(f"Date Range     : {args.start} to {end_date}")
    print(f"DL Backbone    : {args.dl_model}")
    print(f"Lookback Window: {args.lookback} days")
    print(f"Confidence Thresh: {args.threshold}")
    print("-" * 80)

    # 1. Ingest Data
    loader = MarketDataLoader()
    df_raw = loader.fetch_data(ticker=args.ticker, start_date=args.start, end_date=end_date, use_cache=not args.no_cache)
    print(f"[1/6] Ingested {len(df_raw)} price candles.")

    # 2. Technical Indicators & Patterns
    print("[2/6] Calculating technical indicators and detecting candlestick patterns...")
    ind_engine = TechnicalIndicatorEngine()
    df_ind = ind_engine.compute_all(df_raw)
    df_patt = CandlestickPatternDetector.detect_all(df_ind)
    df_full = TechnicalSignalGenerator.generate_signals(df_patt)

    latest_summary = TechnicalSignalGenerator.get_latest_summary(df_full)
    print(f"      Technical Rating: {latest_summary['rating']} (Consensus Score: {latest_summary['consensus_score']:+.2f})")
    print(f"      Bullish Signals : {latest_summary['bullish_signals']} | Bearish Signals: {latest_summary['bearish_signals']}")

    # 3. Preprocessing & Sequence Generation
    print("[3/6] Preprocessing features and constructing temporal sequence windows...")
    model_cfg = ModelConfig(
        lookback_window=args.lookback,
        dl_model_type=args.dl_model,
        dl_epochs=args.epochs
    )
    preprocessor = MarketDataPreprocessor(model_cfg)
    features_df, target_clf, target_reg = preprocessor.prepare_dataset(df_full)

    splits = preprocessor.split_chronological(features_df, target_clf)
    X_train_df, y_train_s = splits['train']
    X_val_df, y_val_s = splits['val']
    X_test_df, y_test_s = splits['test']

    seq_builder = TimeSeriesSequenceBuilder(lookback_window=model_cfg.lookback_window)
    X_seq_train, X_tab_train, y_seq_train, _ = seq_builder.build_sequences(X_train_df, y_train_s)
    X_seq_val, X_tab_val, y_seq_val, _ = seq_builder.build_sequences(X_val_df, y_val_s)
    X_seq_test, X_tab_test, y_seq_test, dates_test = seq_builder.build_sequences(X_test_df, y_test_s)

    print(f"      Train Samples: {len(X_seq_train)} | Val Samples: {len(X_seq_val)} | Test Samples: {len(X_seq_test)}")
    print(f"      Engineered Feature Count: {len(preprocessor.feature_columns)}")

    # 4. Train Hybrid Model
    print("[4/6] Training BiLSTM-Attention / TCN, XGBoost, LightGBM, and Meta-Learners...")
    hybrid = HybridFramework(model_cfg)
    hybrid.train(
        X_seq_train, X_tab_train, y_seq_train,
        X_seq_val, X_tab_val, y_seq_val
    )

    # 5. Out-of-Sample Evaluation
    print("\n[5/6] Evaluating Models on Out-Of-Sample Test Set:")
    eval_df = hybrid.evaluate(X_seq_test, X_tab_test, y_seq_test)
    print("-" * 80)
    print(eval_df.to_string(index=False))
    print("-" * 80)

    # 6. Quantitative Strategy Backtest
    print("\n[6/6] Executing Quantitative Backtest Simulation...")
    backtest_cfg = BacktestConfig(confidence_threshold=args.threshold)
    all_preds = hybrid.predict_all_models(X_seq_test, X_tab_test)
    hybrid_probs = all_preds['Hybrid (Full Framework)']

    backtester = BacktestEngine(backtest_cfg)
    history_df, bt_metrics = backtester.run_backtest(
        price_df=df_full,
        probabilities=hybrid_probs,
        dates=dates_test,
        allow_short=args.allow_short
    )

    print("\n" + "=" * 50)
    print("[+] QUANTITATIVE BACKTEST PERFORMANCE METRICS")
    print("=" * 50)
    for k, v in bt_metrics.items():
        print(f"  {k:<30}: {v}")
    print("=" * 50)

    # Explainability on latest candle
    interpreter = FrameworkInterpreter(hybrid, feature_names=preprocessor.feature_columns)
    latest_explanation = interpreter.explain_prediction(
        X_seq_sample=X_seq_test[-1],
        X_tab_sample=X_tab_test[-1],
        sample_date=str(dates_test[-1].date()),
        price_row=df_full.loc[dates_test[-1]]
    )
    print(f"\n[>] NEXT-DAY FORECAST FOR {args.ticker}:")
    print(f"   Date             : {latest_explanation['date']}")
    print(f"   Trend Sentiment  : {latest_explanation['sentiment']}")
    print(f"   Upward Probability: {latest_explanation['hybrid_probability'] * 100:.1f}%")
    print(f"   Top Influential Indicators: {list(latest_explanation['salient_features'].keys())[:5]}")
    print("=" * 80)
    print("Execution complete! To launch the interactive dashboard, run:")
    print("   streamlit run app/dashboard.py")
    print("=" * 80)


if __name__ == "__main__":
    main()
