@echo off
title Push Project to GitHub - https://github.com/anujkaurav/macro-project-3-
color 0B
echo ===============================================================================
echo   PUSH HYBRID ML-DL FRAMEWORK TO GITHUB
echo   Repository: https://github.com/anujkaurav/macro-project-3-.git
echo ===============================================================================
echo.

cd /d "%~dp0"

if exist "C:\ProgramData\anaconda3\python.exe" (
    set "PYTHON_EXE=C:\ProgramData\anaconda3\python.exe"
) else (
    set "PYTHON_EXE=python"
)

echo [Step 1] Checking local Git repository...
"%PYTHON_EXE%" -c "import os; print('Git repo present' if os.path.exists('.git') else 'Initializing...')"

echo.
echo [Step 2] Authentication with GitHub:
echo GitHub requires a Personal Access Token (PAT) with 'repo' scope to push.
echo If you don't have one yet, generate it in 30 seconds:
echo   1. Visit: https://github.com/settings/tokens
echo   2. Click 'Generate new token' (classic) -> Select 'repo' checkbox -> Click Generate.
echo   3. Copy your token (starts with ghp_...)
echo.
set /p GH_TOKEN="Paste your GitHub Personal Access Token here: "

if "%GH_TOKEN%"=="" (
    echo [!] No token entered. Attempting push with default credentials...
    "%PYTHON_EXE%" push_to_github.py
) else (
    echo.
    echo [*] Authenticating and pushing to https://github.com/anujkaurav/macro-project-3-.git ...
    "%PYTHON_EXE%" push_to_github.py %GH_TOKEN%
)

echo.
echo ===============================================================================
echo   Done. Press any key to close this window.
echo ===============================================================================
pause
