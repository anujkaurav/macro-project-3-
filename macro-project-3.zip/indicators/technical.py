"""
Vectorized Technical Indicator Engine
Pure NumPy and Pandas implementation with mathematical precision and zero lookahead bias.
"""
from typing import Optional, List, Dict
import numpy as np
import pandas as pd
from config import IndicatorConfig


class TechnicalIndicatorEngine:
    """
    Computes a comprehensive suite of trend, momentum, volatility,
    and volume indicators from OHLCV price series.
    """

    def __init__(self, config: Optional[IndicatorConfig] = None):
        self.cfg = config or IndicatorConfig()

    def compute_all(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Calculates all technical indicators and appends them to a copy of the dataframe.
        Expects columns: ['Open', 'High', 'Low', 'Close', 'Volume']
        """
        df = df.copy()
        # Verify required columns exist (case-insensitive check)
        col_map = {c.lower(): c for c in df.columns}
        required = ['open', 'high', 'low', 'close', 'volume']
        for r in required:
            if r not in col_map:
                raise ValueError(f"Missing required column '{r}' in OHLCV DataFrame.")

        c_open = col_map['open']
        c_high = col_map['high']
        c_low = col_map['low']
        c_close = col_map['close']
        c_vol = col_map['volume']

        # 1. Trend Indicators (Moving Averages, MACD, SuperTrend)
        df = self._add_moving_averages(df, c_close)
        df = self._add_macd(df, c_close)
        df = self._add_supertrend(df, c_high, c_low, c_close)

        # 2. Momentum Indicators (RSI, Stochastic, CCI, Williams %R, MFI)
        df = self._add_rsi(df, c_close)
        df = self._add_stochastic(df, c_high, c_low, c_close)
        df = self._add_cci(df, c_high, c_low, c_close)
        df = self._add_williams_r(df, c_high, c_low, c_close)
        df = self._add_mfi(df, c_high, c_low, c_close, c_vol)

        # 3. Volatility Indicators (Bollinger Bands, ATR, Rolling Volatility)
        df = self._add_bollinger_bands(df, c_close)
        df = self._add_atr(df, c_high, c_low, c_close)
        df = self._add_volatility_metrics(df, c_high, c_low, c_close)

        # 4. Directional Trend (ADX, +DI, -DI)
        df = self._add_adx(df, c_high, c_low, c_close)

        # 5. Volume Indicators (OBV, VWAP, CMF)
        df = self._add_volume_indicators(df, c_high, c_low, c_close, c_vol)

        # 6. Stationary Price & Return Features
        df = self._add_price_transforms(df, c_open, c_high, c_low, c_close, c_vol)

        return df

    def _add_moving_averages(self, df: pd.DataFrame, close: str) -> pd.DataFrame:
        for p in self.cfg.sma_periods:
            df[f'SMA_{p}'] = df[close].rolling(window=p, min_periods=p).mean()
            # Ratio of price to SMA for scale-invariance
            df[f'Ratio_SMA_{p}'] = (df[close] / df[f'SMA_{p}']) - 1.0

        for p in self.cfg.ema_periods:
            df[f'EMA_{p}'] = df[close].ewm(span=p, adjust=False).mean()
            df[f'Ratio_EMA_{p}'] = (df[close] / df[f'EMA_{p}']) - 1.0

        # Moving average crossover spreads
        if 20 in self.cfg.sma_periods and 50 in self.cfg.sma_periods:
            df['SMA_Spread_20_50'] = (df['SMA_20'] - df['SMA_50']) / df['SMA_50']
        if 50 in self.cfg.sma_periods and 200 in self.cfg.sma_periods:
            df['Golden_Cross_Spread'] = (df['SMA_50'] - df['SMA_200']) / df['SMA_200']

        return df

    def _add_macd(self, df: pd.DataFrame, close: str) -> pd.DataFrame:
        ema_fast = df[close].ewm(span=self.cfg.macd_fast, adjust=False).mean()
        ema_slow = df[close].ewm(span=self.cfg.macd_slow, adjust=False).mean()
        macd_line = ema_fast - ema_slow
        signal_line = macd_line.ewm(span=self.cfg.macd_signal, adjust=False).mean()
        macd_hist = macd_line - signal_line

        df['MACD'] = macd_line
        df['MACD_Signal'] = signal_line
        df['MACD_Hist'] = macd_hist
        # Normalized MACD by price
        df['MACD_Normalized'] = macd_line / df[close]
        return df

    def _add_rsi(self, df: pd.DataFrame, close: str) -> pd.DataFrame:
        delta = df[close].diff()
        gain = delta.clip(lower=0)
        loss = -delta.clip(upper=0)

        # Wilder's Exponential Smoothing
        alpha = 1.0 / self.cfg.rsi_period
        avg_gain = gain.ewm(alpha=alpha, adjust=False).mean()
        avg_loss = loss.ewm(alpha=alpha, adjust=False).mean()

        rs = avg_gain / avg_loss.replace(0, np.nan)
        rsi = 100.0 - (100.0 / (1.0 + rs))
        df['RSI'] = rsi.fillna(50.0)
        return df

    def _add_bollinger_bands(self, df: pd.DataFrame, close: str) -> pd.DataFrame:
        p = self.cfg.bb_period
        k = self.cfg.bb_std
        mid = df[close].rolling(window=p, min_periods=p).mean()
        std = df[close].rolling(window=p, min_periods=p).std()

        upper = mid + (k * std)
        lower = mid - (k * std)

        df['BB_Mid'] = mid
        df['BB_Upper'] = upper
        df['BB_Lower'] = lower
        # %B: Position within bands [0, 1]
        band_diff = upper - lower
        df['BB_PercentB'] = (df[close] - lower) / band_diff.replace(0, np.nan)
        # Bandwidth: measure of volatility squeeze
        df['BB_Bandwidth'] = band_diff / mid.replace(0, np.nan)
        return df

    def _add_atr(self, df: pd.DataFrame, high: str, low: str, close: str) -> pd.DataFrame:
        prev_close = df[close].shift(1)
        tr1 = df[high] - df[low]
        tr2 = (df[high] - prev_close).abs()
        tr3 = (df[low] - prev_close).abs()
        true_range = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)

        atr = true_range.ewm(alpha=1.0 / self.cfg.atr_period, adjust=False).mean()
        df['True_Range'] = true_range
        df['ATR'] = atr
        df['ATR_Ratio'] = atr / df[close]
        return df

    def _add_stochastic(self, df: pd.DataFrame, high: str, low: str, close: str) -> pd.DataFrame:
        k_period = self.cfg.stoch_k
        d_period = self.cfg.stoch_d

        lowest_low = df[low].rolling(window=k_period, min_periods=k_period).min()
        highest_high = df[high].rolling(window=k_period, min_periods=k_period).max()

        denom = highest_high - lowest_low
        stoch_k = 100.0 * ((df[close] - lowest_low) / denom.replace(0, np.nan))
        stoch_d = stoch_k.rolling(window=d_period, min_periods=d_period).mean()

        df['Stoch_K'] = stoch_k.fillna(50.0)
        df['Stoch_D'] = stoch_d.fillna(50.0)
        return df

    def _add_cci(self, df: pd.DataFrame, high: str, low: str, close: str) -> pd.DataFrame:
        p = self.cfg.cci_period
        tp = (df[high] + df[low] + df[close]) / 3.0
        sma_tp = tp.rolling(window=p, min_periods=p).mean()
        # Mean absolute deviation
        mad = tp.rolling(window=p, min_periods=p).apply(
            lambda x: np.mean(np.abs(x - np.mean(x))), raw=True
        )
        cci = (tp - sma_tp) / (0.015 * mad.replace(0, np.nan))
        df['CCI'] = cci.fillna(0.0)
        return df

    def _add_williams_r(self, df: pd.DataFrame, high: str, low: str, close: str) -> pd.DataFrame:
        p = 14
        highest_high = df[high].rolling(window=p, min_periods=p).max()
        lowest_low = df[low].rolling(window=p, min_periods=p).min()
        denom = highest_high - lowest_low
        wr = -100.0 * ((highest_high - df[close]) / denom.replace(0, np.nan))
        df['Williams_R'] = wr.fillna(-50.0)
        return df

    def _add_mfi(self, df: pd.DataFrame, high: str, low: str, close: str, vol: str) -> pd.DataFrame:
        p = self.cfg.mfi_period
        typical_price = (df[high] + df[low] + df[close]) / 3.0
        raw_money_flow = typical_price * df[vol]

        price_diff = typical_price.diff()
        pos_flow = raw_money_flow.where(price_diff > 0, 0.0)
        neg_flow = raw_money_flow.where(price_diff < 0, 0.0)

        pos_sum = pos_flow.rolling(window=p, min_periods=p).sum()
        neg_sum = neg_flow.rolling(window=p, min_periods=p).sum()

        money_ratio = pos_sum / neg_sum.replace(0, np.nan)
        mfi = 100.0 - (100.0 / (1.0 + money_ratio))
        df['MFI'] = mfi.fillna(50.0)
        return df

    def _add_adx(self, df: pd.DataFrame, high: str, low: str, close: str) -> pd.DataFrame:
        p = self.cfg.adx_period
        up_move = df[high].diff()
        down_move = -df[low].diff()

        plus_dm = np.where((up_move > down_move) & (up_move > 0), up_move, 0.0)
        minus_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0.0)

        plus_dm_s = pd.Series(plus_dm, index=df.index).ewm(alpha=1.0 / p, adjust=False).mean()
        minus_dm_s = pd.Series(minus_dm, index=df.index).ewm(alpha=1.0 / p, adjust=False).mean()

        atr = df['ATR'] if 'ATR' in df else (df[high] - df[low]).ewm(alpha=1.0 / p, adjust=False).mean()
        plus_di = 100.0 * (plus_dm_s / atr.replace(0, np.nan))
        minus_di = 100.0 * (minus_dm_s / atr.replace(0, np.nan))

        dx = 100.0 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)
        adx = dx.ewm(alpha=1.0 / p, adjust=False).mean()

        df['Plus_DI'] = plus_di.fillna(0.0)
        df['Minus_DI'] = minus_di.fillna(0.0)
        df['ADX'] = adx.fillna(0.0)
        return df

    def _add_supertrend(self, df: pd.DataFrame, high: str, low: str, close: str) -> pd.DataFrame:
        p = self.cfg.supertrend_period
        m = self.cfg.supertrend_multiplier

        # Calculate basic upper and lower bands
        atr = df['ATR'] if 'ATR' in df else (df[high] - df[low]).rolling(p).mean()
        hl2 = (df[high] + df[low]) / 2.0
        upper_band = hl2 + (m * atr)
        lower_band = hl2 - (m * atr)

        st = np.zeros(len(df))
        direction = np.zeros(len(df))  # +1 Bullish, -1 Bearish

        c_vals = df[close].values
        u_vals = upper_band.values
        l_vals = lower_band.values

        curr_in_uptrend = True
        curr_upper = u_vals[0] if len(u_vals) > 0 else 0
        curr_lower = l_vals[0] if len(l_vals) > 0 else 0

        for i in range(len(df)):
            if i == 0:
                st[i] = curr_lower
                direction[i] = 1
                continue

            # Trailing bands
            curr_lower = max(l_vals[i], curr_lower) if c_vals[i-1] > curr_lower else l_vals[i]
            curr_upper = min(u_vals[i], curr_upper) if c_vals[i-1] < curr_upper else u_vals[i]

            if curr_in_uptrend:
                if c_vals[i] < curr_lower:
                    curr_in_uptrend = False
                    st[i] = curr_upper
                    direction[i] = -1
                else:
                    st[i] = curr_lower
                    direction[i] = 1
            else:
                if c_vals[i] > curr_upper:
                    curr_in_uptrend = True
                    st[i] = curr_lower
                    direction[i] = 1
                else:
                    st[i] = curr_upper
                    direction[i] = -1

        df['SuperTrend'] = st
        df['SuperTrend_Direction'] = direction
        return df

    def _add_volume_indicators(self, df: pd.DataFrame, high: str, low: str, close: str, vol: str) -> pd.DataFrame:
        # On-Balance Volume (OBV)
        direction = np.sign(df[close].diff()).fillna(0)
        obv = (direction * df[vol]).cumsum()
        df['OBV'] = obv
        df['OBV_EMA20'] = obv.ewm(span=20, adjust=False).mean()
        df['OBV_Ratio'] = (obv - df['OBV_EMA20']) / (df['OBV_EMA20'].abs() + 1e-8)

        # Chaikin Money Flow (CMF) 20-period
        p = 20
        mf_mult = ((df[close] - df[low]) - (df[high] - df[close])) / (df[high] - df[low]).replace(0, np.nan)
        mf_volume = mf_mult * df[vol]
        cmf = mf_volume.rolling(p).sum() / df[vol].rolling(p).sum().replace(0, np.nan)
        df['CMF'] = cmf.fillna(0.0)

        # Rolling 20-period VWAP approximation
        typical_price = (df[high] + df[low] + df[close]) / 3.0
        pv = typical_price * df[vol]
        vwap = pv.rolling(p).sum() / df[vol].rolling(p).sum().replace(0, np.nan)
        df['VWAP_20'] = vwap
        df['Ratio_VWAP'] = (df[close] / vwap) - 1.0
        return df

    def _add_volatility_metrics(self, df: pd.DataFrame, high: str, low: str, close: str) -> pd.DataFrame:
        # Log returns
        log_ret = np.log(df[close] / df[close].shift(1))
        # 20-day annualized historical volatility
        df['Hist_Volatility_20'] = log_ret.rolling(20).std() * np.sqrt(252)

        # Garman-Klass Volatility (incorporates High, Low, Open, Close)
        c_open = df.columns[df.columns.str.lower() == 'open'][0]
        log_hl = np.log(df[high] / df[low])
        log_co = np.log(df[close] / df[c_open])
        gk_var = 0.5 * (log_hl ** 2) - (2 * np.log(2) - 1) * (log_co ** 2)
        df['Garman_Klass_Vol'] = np.sqrt(gk_var.rolling(20).mean() * 252)
        return df

    def _add_price_transforms(self, df: pd.DataFrame, c_open: str, c_high: str, c_low: str, c_close: str, c_vol: str) -> pd.DataFrame:
        # Stationary returns
        df['Return_1d'] = df[c_close].pct_change(1)
        df['Return_5d'] = df[c_close].pct_change(5)
        df['Return_10d'] = df[c_close].pct_change(10)
        df['Log_Return'] = np.log(df[c_close] / df[c_close].shift(1))

        # Intraday ranges
        df['Intraday_Range'] = (df[c_high] - df[c_low]) / df[c_close]
        df['Body_Size'] = (df[c_close] - df[c_open]).abs() / df[c_close]

        # Normalized volume change
        vol_ma = df[c_vol].rolling(20).mean()
        df['Volume_Ratio_20'] = df[c_vol] / vol_ma.replace(0, np.nan)

        return df
