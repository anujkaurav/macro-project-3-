"""
Vectorized Candlestick Pattern Detection Engine
Extracts classic price action and candlestick morphology signals.
"""
import numpy as np
import pandas as pd


class CandlestickPatternDetector:
    """
    Detects high-conviction candlestick patterns without lookahead bias.
    Values are typically +1 (Bullish), -1 (Bearish), or 0 (Neutral).
    """

    @staticmethod
    def detect_all(df: pd.DataFrame) -> pd.DataFrame:
        """
        Appends binary/ternary candlestick indicator columns to DataFrame.
        """
        res = df.copy()
        col_map = {c.lower(): c for c in res.columns}
        o = res[col_map['open']]
        h = res[col_map['high']]
        l = res[col_map['low']]
        c = res[col_map['close']]

        body = (c - o).abs()
        candle_range = (h - l).replace(0, 1e-6)
        upper_shadow = h - np.maximum(o, c)
        lower_shadow = np.minimum(o, c) - l

        # Relative measurements
        body_ratio = body / candle_range
        upper_shadow_ratio = upper_shadow / candle_range
        lower_shadow_ratio = lower_shadow / candle_range

        # 1. Doji: Very small body relative to entire candle range (< 10%)
        is_doji = (body_ratio < 0.10).astype(int)
        res['Pattern_Doji'] = is_doji

        # 2. Hammer: Bullish reversal with long lower shadow (> 60%), tiny upper shadow (< 10%)
        is_hammer = (
            (lower_shadow_ratio >= 0.60) &
            (upper_shadow_ratio <= 0.10) &
            (body_ratio <= 0.30)
        ).astype(int)
        res['Pattern_Hammer'] = is_hammer

        # 3. Inverted Hammer / Shooting Star:
        # Long upper shadow (> 60%), tiny lower shadow (< 10%)
        is_inverted = (
            (upper_shadow_ratio >= 0.60) &
            (lower_shadow_ratio <= 0.10) &
            (body_ratio <= 0.30)
        ).astype(int)
        res['Pattern_Inverted_Hammer'] = is_inverted

        # 4. Bullish Engulfing: Current green body completely covers previous red body
        prev_o = o.shift(1)
        prev_c = c.shift(1)
        is_prev_red = prev_c < prev_o
        is_curr_green = c > o
        engulfs_body = (c >= prev_o) & (o <= prev_c)
        is_bullish_engulfing = (is_prev_red & is_curr_green & engulfs_body).astype(int)
        res['Pattern_Bullish_Engulfing'] = is_bullish_engulfing

        # 5. Bearish Engulfing: Current red body completely covers previous green body
        is_prev_green = prev_c > prev_o
        is_curr_red = c < o
        bearish_engulfs = (o >= prev_c) & (c <= prev_o)
        is_bearish_engulfing = (is_prev_green & is_curr_red & bearish_engulfs).astype(int)
        res['Pattern_Bearish_Engulfing'] = is_bearish_engulfing

        # 6. Marubozu: Strong conviction candle with almost no shadows (> 85% body)
        is_bullish_marubozu = ((body_ratio > 0.85) & (c > o)).astype(int)
        is_bearish_marubozu = ((body_ratio > 0.85) & (c < o)).astype(int)
        res['Pattern_Bullish_Marubozu'] = is_bullish_marubozu
        res['Pattern_Bearish_Marubozu'] = is_bearish_marubozu

        # 7. Aggregate Pattern Score: Sum of bullish patterns minus bearish patterns
        res['Pattern_Composite_Score'] = (
            is_hammer + is_bullish_engulfing + is_bullish_marubozu -
            is_inverted - is_bearish_engulfing - is_bearish_marubozu
        )

        return res
