"""
Technical Signal Generator and Composite Consensus Matrix
Converts technical indicators and price action into standardized directional ratings.
"""
from typing import Dict, Any, List
import pandas as pd
import numpy as np


class TechnicalSignalGenerator:
    """
    Evaluates indicator states into discrete +1 (Bullish), 0 (Neutral), -1 (Bearish) signals
    and generates an aggregated consensus technical score.
    """

    @staticmethod
    def generate_signals(df: pd.DataFrame) -> pd.DataFrame:
        """
        Takes DataFrame with computed indicators and appends Signal_* columns
        plus Technical_Consensus_Score.
        """
        sig = df.copy()

        # 1. Trend Signals
        # SMA 20 vs SMA 50
        if 'SMA_20' in sig.columns and 'SMA_50' in sig.columns:
            sig['Signal_SMA_Cross'] = np.where(sig['SMA_20'] > sig['SMA_50'], 1, -1)
        else:
            sig['Signal_SMA_Cross'] = 0

        # EMA 9 vs EMA 21
        if 'EMA_9' in sig.columns and 'EMA_21' in sig.columns:
            sig['Signal_EMA_Cross'] = np.where(sig['EMA_9'] > sig['EMA_21'], 1, -1)
        else:
            sig['Signal_EMA_Cross'] = 0

        # MACD Line vs Signal
        if 'MACD' in sig.columns and 'MACD_Signal' in sig.columns:
            sig['Signal_MACD'] = np.where(sig['MACD'] > sig['MACD_Signal'], 1, -1)
        else:
            sig['Signal_MACD'] = 0

        # SuperTrend Direction
        if 'SuperTrend_Direction' in sig.columns:
            sig['Signal_SuperTrend'] = sig['SuperTrend_Direction']
        else:
            sig['Signal_SuperTrend'] = 0

        # 2. Momentum Signals
        # RSI Mean-Reversion / Trend
        if 'RSI' in sig.columns:
            # Bullish if recovering from oversold, bearish if falling from overbought,
            # or momentum direction based on 50 midline
            sig['Signal_RSI'] = np.where(sig['RSI'] > 55, 1, np.where(sig['RSI'] < 45, -1, 0))
        else:
            sig['Signal_RSI'] = 0

        # Stochastic Oscillator
        if 'Stoch_K' in sig.columns and 'Stoch_D' in sig.columns:
            sig['Signal_Stoch'] = np.where(
                (sig['Stoch_K'] > sig['Stoch_D']) & (sig['Stoch_K'] < 80), 1,
                np.where((sig['Stoch_K'] < sig['Stoch_D']) & (sig['Stoch_K'] > 20), -1, 0)
            )
        else:
            sig['Signal_Stoch'] = 0

        # ADX Directional Trend
        if 'Plus_DI' in sig.columns and 'Minus_DI' in sig.columns and 'ADX' in sig.columns:
            has_trend = sig['ADX'] > 20
            bullish_di = sig['Plus_DI'] > sig['Minus_DI']
            sig['Signal_ADX_Trend'] = np.where(has_trend & bullish_di, 1, np.where(has_trend & (~bullish_di), -1, 0))
        else:
            sig['Signal_ADX_Trend'] = 0

        # 3. Volatility Signals
        # Bollinger Bands %B
        if 'BB_PercentB' in sig.columns:
            sig['Signal_BB'] = np.where(sig['BB_PercentB'] > 0.8, 1, np.where(sig['BB_PercentB'] < 0.2, -1, 0))
        else:
            sig['Signal_BB'] = 0

        # 4. Volume Signals
        # OBV relative to EMA
        if 'OBV_Ratio' in sig.columns:
            sig['Signal_OBV'] = np.where(sig['OBV_Ratio'] > 0.01, 1, np.where(sig['OBV_Ratio'] < -0.01, -1, 0))
        else:
            sig['Signal_OBV'] = 0

        # CMF (Chaikin Money Flow)
        if 'CMF' in sig.columns:
            sig['Signal_CMF'] = np.where(sig['CMF'] > 0.05, 1, np.where(sig['CMF'] < -0.05, -1, 0))
        else:
            sig['Signal_CMF'] = 0

        # Candlestick Pattern Signal
        if 'Pattern_Composite_Score' in sig.columns:
            sig['Signal_Patterns'] = np.sign(sig['Pattern_Composite_Score'])
        else:
            sig['Signal_Patterns'] = 0

        # Composite Consensus Score
        signal_cols = [c for c in sig.columns if c.startswith('Signal_')]
        sig['Consensus_Bullish_Count'] = (sig[signal_cols] > 0).sum(axis=1)
        sig['Consensus_Bearish_Count'] = (sig[signal_cols] < 0).sum(axis=1)
        sig['Consensus_Neutral_Count'] = (sig[signal_cols] == 0).sum(axis=1)

        # Normalized Consensus Score between -1.0 (Strong Sell) to +1.0 (Strong Buy)
        total_signals = len(signal_cols)
        if total_signals > 0:
            sig['Technical_Consensus_Score'] = (
                sig['Consensus_Bullish_Count'] - sig['Consensus_Bearish_Count']
            ) / total_signals
        else:
            sig['Technical_Consensus_Score'] = 0.0

        return sig

    @classmethod
    def get_latest_summary(cls, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Returns a concise dictionary summary of the latest day's technical indicator signals.
        """
        if df.empty:
            return {}
        last_row = df.iloc[-1]
        signals = {
            c.replace('Signal_', ''): int(last_row[c])
            for c in df.columns if c.startswith('Signal_')
        }
        score = float(last_row.get('Technical_Consensus_Score', 0.0))
        if score > 0.35:
            rating = "Strong Buy"
        elif score > 0.10:
            rating = "Buy"
        elif score < -0.35:
            rating = "Strong Sell"
        elif score < -0.10:
            rating = "Sell"
        else:
            rating = "Neutral"

        return {
            "consensus_score": round(score, 3),
            "rating": rating,
            "signals": signals,
            "bullish_signals": int(last_row.get('Consensus_Bullish_Count', 0)),
            "bearish_signals": int(last_row.get('Consensus_Bearish_Count', 0)),
            "neutral_signals": int(last_row.get('Consensus_Neutral_Count', 0)),
        }
