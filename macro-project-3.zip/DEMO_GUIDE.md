# 🎮 Demo Version Guide: Hybrid ML-DL Stock Market Trend Prediction

Welcome to the **Demo Version** of the Hybrid ML-DL Framework for Time-Series Stock Market Trend Prediction and Technical Analysis.

---

## 🚀 Quick Launch (Choose Your Preferred Interface)

### Option A: Interactive CLI Menu (Terminal Demo)
Double-click [`RUN_DEMO.bat`](file:///c:/Users/anike/OneDrive/Desktop/Complete%20c++/New%20folder/RUN_DEMO.bat) or run in terminal:
```powershell
& "C:\ProgramData\anaconda3\python.exe" demo.py
```
This launches an interactive terminal console with 6 menu options:
1. **Model Benchmark Comparison** (BiLSTM vs XGBoost vs LightGBM vs Stacking vs Feature Fusion)
2. **Quantitative Backtest & Risk Statistics** (Sharpe, Sortino, Calmar, Max Drawdown, VaR 95%)
3. **Explainable AI (XAI)** (Temporal Attention Distribution & Gini Feature Importance)
4. **Live 15-Second Pipeline Demo** (Live model training & execution)
5. **Launch Interactive Web Dashboard** (Streamlit GUI)
6. **Open Standalone Presentation Showcase** in Browser

---

### Option B: Interactive Visual Web Dashboard (GUI)
Double-click [`RUN_DASHBOARD.bat`](file:///c:/Users/anike/OneDrive/Desktop/Complete%20c++/New%20folder/RUN_DASHBOARD.bat) or run:
```powershell
& "C:\ProgramData\anaconda3\python.exe" -m streamlit run app/dashboard.py
```
Opens in your browser at `http://localhost:8501`.
* **Zero-Wait Instant Demo:** Out-of-sample benchmark on Apple Inc. (`AAPL`) is pre-loaded on boot.
* **Tabs:**
  - `Tab 1: Market & Technical Analysis` (Interactive Plotly candlesticks + Bollinger Bands + MACD + RSI)
  - `Tab 2: Hybrid Model Benchmarking` (Model comparison metrics table + grouped bar chart)
  - `Tab 3: Quantitative Backtesting` (Portfolio equity curve vs Buy & Hold + underwater drawdown)
  - `Tab 4: Explainability & AI Insights` (Temporal lookback attention profile + top indicator rankings)
* **Custom Live Run:** Select any asset (`NVDA`, `TSLA`, `MSFT`, `SPY`) in the sidebar to train on live market data.

---

### Option C: Standalone Zero-Server Web Presentation
Double-click [`presentation_showcase.html`](file:///c:/Users/anike/OneDrive/Desktop/Complete%20c++/New%20folder/presentation_showcase.html).
* Runs directly in Google Chrome, Microsoft Edge, or Firefox.
* Zero installation or server needed.
* Contains interactive **Chart.js** dynamic graphs, math equations, and viva presentation notes.

---

## 📦 What Is Included in This Demo Version?

| Component | File / Asset | Functionality |
| :--- | :--- | :--- |
| **Interactive Demo Menu** | [`demo.py`](file:///c:/Users/anike/OneDrive/Desktop/Complete%20c++/New%20folder/demo.py) | Full-featured CLI menu for quick testing |
| **1-Click Demo Launcher** | [`RUN_DEMO.bat`](file:///c:/Users/anike/OneDrive/Desktop/Complete%20c++/New%20folder/RUN_DEMO.bat) | Windows batch file to launch `demo.py` |
| **1-Click GUI Launcher** | [`RUN_DASHBOARD.bat`](file:///c:/Users/anike/OneDrive/Desktop/Complete%20c++/New%20folder/RUN_DASHBOARD.bat) | Windows batch file to launch Streamlit GUI |
| **1-Click CLI Benchmark** | [`RUN_CLI_DEMO.bat`](file:///c:/Users/anike/OneDrive/Desktop/Complete%20c++/New%20folder/RUN_CLI_DEMO.bat) | Automated CLI execution on AAPL |
| **Standalone Showcase** | [`presentation_showcase.html`](file:///c:/Users/anike/OneDrive/Desktop/Complete%20c++/New%20folder/presentation_showcase.html) | Browser-based interactive presentation |
| **Presentation Notes** | [`PROJECT_SHOWCASE.md`](file:///c:/Users/anike/OneDrive/Desktop/Complete%20c++/New%20folder/PROJECT_SHOWCASE.md) | 5-min presentation script & Top 10 Viva Q&A |
| **Pre-Calculated Cache** | [`data_cache/demo_payload_AAPL.pkl`](file:///c:/Users/anike/OneDrive/Desktop/Complete%20c++/New%20folder/data_cache/demo_payload_AAPL.pkl) | Instant-load out-of-sample benchmark payload |
| **Fast Pipeline Runner** | [`run_demo.py`](file:///c:/Users/anike/OneDrive/Desktop/Complete%20c++/New%20folder/run_demo.py) | 15-second live pipeline script |
