"""
Deep Learning Architectures for Time-Series Market Prediction
Implements BiLSTM with Temporal Attention and TCN-Transformer models in PyTorch.
"""
from typing import Tuple, Optional, Dict
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from config import ModelConfig


class TemporalAttention(nn.Module):
    """
    Bahdanau-style Temporal Self-Attention over sequential hidden states.
    Allows extracting attention weights to visualize which historical days drove the prediction.
    """

    def __init__(self, hidden_dim: int):
        super().__init__()
        self.projection = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.Tanh(),
            nn.Linear(hidden_dim // 2, 1, bias=False)
        )

    def forward(self, hidden_states: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        # hidden_states: (batch_size, seq_len, hidden_dim)
        scores = self.projection(hidden_states)  # (batch_size, seq_len, 1)
        weights = torch.softmax(scores, dim=1)    # (batch_size, seq_len, 1)
        context = torch.sum(hidden_states * weights, dim=1)  # (batch_size, hidden_dim)
        return context, weights.squeeze(-1)


class BiLSTMAttentionModel(nn.Module):
    """
    Bidirectional LSTM with Temporal Attention and Deep Feature Extraction Head.
    """

    def __init__(
        self,
        input_dim: int,
        hidden_dim: int = 64,
        num_layers: int = 2,
        dropout: float = 0.2,
        bidirectional: bool = True
    ):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.bidirectional = bidirectional
        self.num_directions = 2 if bidirectional else 1
        self.effective_hidden = hidden_dim * self.num_directions

        self.lstm = nn.LSTM(
            input_size=input_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            dropout=dropout if num_layers > 1 else 0.0,
            batch_first=True,
            bidirectional=bidirectional
        )

        self.attention = TemporalAttention(self.effective_hidden)
        self.layer_norm = nn.LayerNorm(self.effective_hidden)

        # Classification / Regression Head
        self.latent_dim = 32
        self.fc_latent = nn.Sequential(
            nn.Linear(self.effective_hidden, self.latent_dim),
            nn.GELU(),
            nn.Dropout(dropout)
        )
        self.out_head = nn.Linear(self.latent_dim, 1)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        # x: (batch_size, seq_len, input_dim)
        lstm_out, _ = self.lstm(x)  # (batch_size, seq_len, effective_hidden)
        context, attn_weights = self.attention(lstm_out)
        normed = self.layer_norm(context)
        latent = self.fc_latent(normed)
        logits = self.out_head(latent)
        return logits.squeeze(-1), latent, attn_weights

    def extract_features(self, x: torch.Tensor) -> torch.Tensor:
        """Extracts latent temporal embedding vectors for Hybrid feature fusion."""
        with torch.no_grad():
            _, latent, _ = self.forward(x)
            return latent


class TCNTransformerModel(nn.Module):
    """
    Hybrid Temporal Convolutional Network (TCN) + Positional Transformer Encoder.
    Combines local dilated convolutional receptive fields with multi-head self-attention.
    """

    def __init__(
        self,
        input_dim: int,
        hidden_dim: int = 64,
        nhead: int = 4,
        num_layers: int = 2,
        dropout: float = 0.2
    ):
        super().__init__()
        # 1D Causal Dilated Convolutions
        self.tcn_conv1 = nn.Conv1d(input_dim, hidden_dim, kernel_size=3, padding=1)
        self.tcn_conv2 = nn.Conv1d(hidden_dim, hidden_dim, kernel_size=3, dilation=2, padding=2)
        self.relu = nn.GELU()
        self.conv_norm = nn.LayerNorm(hidden_dim)

        # Transformer Encoder
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim,
            nhead=nhead,
            dim_feedforward=hidden_dim * 2,
            dropout=dropout,
            batch_first=True
        )
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)

        self.latent_dim = 32
        self.fc_latent = nn.Sequential(
            nn.Linear(hidden_dim, self.latent_dim),
            nn.GELU(),
            nn.Dropout(dropout)
        )
        self.out_head = nn.Linear(self.latent_dim, 1)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        # x: (batch_size, seq_len, input_dim)
        batch_size, seq_len, _ = x.shape
        x_trans = x.transpose(1, 2)  # (batch_size, input_dim, seq_len)

        # TCN block
        conv1 = self.relu(self.tcn_conv1(x_trans))
        conv2 = self.relu(self.tcn_conv2(conv1))
        conv_out = conv2.transpose(1, 2)  # (batch_size, seq_len, hidden_dim)
        conv_out = self.conv_norm(conv_out)

        # Transformer encoding
        trans_out = self.transformer_encoder(conv_out)  # (batch_size, seq_len, hidden_dim)

        # Mean pooling over sequence
        pooled = trans_out.mean(dim=1)
        latent = self.fc_latent(pooled)
        logits = self.out_head(latent)

        # Uniform dummy attention weights for compatibility
        dummy_weights = torch.ones(batch_size, seq_len, device=x.device) / seq_len
        return logits.squeeze(-1), latent, dummy_weights

    def extract_features(self, x: torch.Tensor) -> torch.Tensor:
        with torch.no_grad():
            _, latent, _ = self.forward(x)
            return latent


class DeepLearningTrainer:
    """
    Handles robust PyTorch training with Early Stopping, AdamW, and Learning Rate Scheduling.
    """

    def __init__(self, config: Optional[ModelConfig] = None):
        self.cfg = config or ModelConfig()
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model: Optional[nn.Module] = None

    def build_model(self, input_dim: int) -> nn.Module:
        if self.cfg.dl_model_type == "tcn_transformer":
            model = TCNTransformerModel(
                input_dim=input_dim,
                hidden_dim=self.cfg.hidden_dim,
                nhead=self.cfg.attention_heads,
                num_layers=self.cfg.num_layers,
                dropout=self.cfg.dropout
            )
        else:
            model = BiLSTMAttentionModel(
                input_dim=input_dim,
                hidden_dim=self.cfg.hidden_dim,
                num_layers=self.cfg.num_layers,
                dropout=self.cfg.dropout,
                bidirectional=self.cfg.bidirectional
            )
        self.model = model.to(self.device)
        return self.model

    def train(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        X_val: np.ndarray,
        y_val: np.ndarray,
        epochs: Optional[int] = None,
        batch_size: Optional[int] = None
    ) -> Dict[str, list]:
        """
        Trains deep learning model with early stopping on validation binary cross entropy.
        """
        if self.model is None:
            input_dim = X_train.shape[2]
            self.build_model(input_dim)

        epochs = epochs or self.cfg.dl_epochs
        batch_size = batch_size or self.cfg.dl_batch_size

        train_ds = TensorDataset(
            torch.tensor(X_train, dtype=torch.float32),
            torch.tensor(y_train, dtype=torch.float32)
        )
        val_ds = TensorDataset(
            torch.tensor(X_val, dtype=torch.float32),
            torch.tensor(y_val, dtype=torch.float32)
        )

        train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False)

        criterion = nn.BCEWithLogitsLoss()
        optimizer = torch.optim.AdamW(
            self.model.parameters(),
            lr=self.cfg.learning_rate,
            weight_decay=self.cfg.weight_decay
        )
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, mode='min', factor=0.5, patience=4
        )

        history = {'train_loss': [], 'val_loss': [], 'val_acc': []}
        best_val_loss = float('inf')
        best_state = None
        patience = 8
        patience_counter = 0

        for epoch in range(1, epochs + 1):
            self.model.train()
            train_loss_total = 0.0

            for batch_x, batch_y in train_loader:
                batch_x = batch_x.to(self.device)
                batch_y = batch_y.to(self.device)

                optimizer.zero_grad()
                logits, _, _ = self.model(batch_x)
                loss = criterion(logits, batch_y)
                loss.backward()
                nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
                optimizer.step()

                train_loss_total += loss.item() * len(batch_y)

            train_loss = train_loss_total / len(train_ds)

            # Validation
            self.model.eval()
            val_loss_total = 0.0
            correct = 0

            with torch.no_grad():
                for batch_x, batch_y in val_loader:
                    batch_x = batch_x.to(self.device)
                    batch_y = batch_y.to(self.device)

                    logits, _, _ = self.model(batch_x)
                    loss = criterion(logits, batch_y)
                    val_loss_total += loss.item() * len(batch_y)

                    preds = (torch.sigmoid(logits) >= 0.5).float()
                    correct += (preds == batch_y).sum().item()

            val_loss = val_loss_total / len(val_ds)
            val_acc = correct / len(val_ds)
            scheduler.step(val_loss)

            history['train_loss'].append(train_loss)
            history['val_loss'].append(val_loss)
            history['val_acc'].append(val_acc)

            if val_loss < best_val_loss:
                best_val_loss = val_loss
                best_state = {k: v.cpu().clone() for k, v in self.model.state_dict().items()}
                patience_counter = 0
            else:
                patience_counter += 1
                if patience_counter >= patience:
                    break

        if best_state is not None:
            self.model.load_state_dict({k: v.to(self.device) for k, v in best_state.items()})

        return history

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Returns 1D array of probabilities P(Target=1) for Up/Bullish."""
        self.model.eval()
        t_x = torch.tensor(X, dtype=torch.float32).to(self.device)
        with torch.no_grad():
            logits, _, _ = self.model(t_x)
            probs = torch.sigmoid(logits).cpu().numpy()
        return probs

    def predict(self, X: np.ndarray, threshold: float = 0.5) -> np.ndarray:
        probs = self.predict_proba(X)
        return (probs >= threshold).astype(int)

    def extract_latent_features(self, X: np.ndarray) -> np.ndarray:
        """Extracts latent representation embeddings (samples, latent_dim)."""
        self.model.eval()
        t_x = torch.tensor(X, dtype=torch.float32).to(self.device)
        with torch.no_grad():
            latent = self.model.extract_features(t_x)
            return latent.cpu().numpy()

    def get_attention_weights(self, X: np.ndarray) -> np.ndarray:
        """Extracts attention weights (samples, lookback_window)."""
        self.model.eval()
        t_x = torch.tensor(X, dtype=torch.float32).to(self.device)
        with torch.no_grad():
            _, _, attn = self.model(t_x)
            return attn.cpu().numpy()
