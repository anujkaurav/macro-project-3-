"""
Hybrid ML-DL Synthesis Framework
Combines Deep Learning sequence modeling (BiLSTM+Attention / TCN-Transformer)
with Gradient Boosted Decision Trees (XGBoost / LightGBM) via Stacking,
Feature Fusion, and Adaptive Blending.
"""
from typing import Dict, Any, Optional, Tuple, List
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, brier_score_loss
)
from config import ModelConfig
from .dl_models import DeepLearningTrainer
from .ml_models import XGBoostModelWrapper, LightGBMModelWrapper, RandomForestModelWrapper


class HybridFramework:
    """
    Orchestrates training, fusion, and inference across ML and DL models.
    """

    def __init__(self, config: Optional[ModelConfig] = None):
        self.cfg = config or ModelConfig()

        # Base Learners
        self.dl_trainer = DeepLearningTrainer(self.cfg)
        self.xgb_model = XGBoostModelWrapper(self.cfg)
        self.lgb_model = LightGBMModelWrapper(self.cfg)
        self.rf_model = RandomForestModelWrapper(self.cfg)

        # Meta-Learner for Stacking
        self.meta_learner = LogisticRegression(C=1.0, solver='lbfgs', max_iter=500)

        # Feature Fusion Model (Boosted tree trained on concatenated [tabular + latent DL])
        self.fusion_xgb = XGBoostModelWrapper(self.cfg)

        # Adaptive Blending Weights
        self.model_weights = {
            'dl': 0.35,
            'xgb': 0.30,
            'lgb': 0.25,
            'rf': 0.10
        }
        self.is_fitted = False

    def train(
        self,
        X_seq_train: np.ndarray,
        X_tab_train: np.ndarray,
        y_train: np.ndarray,
        X_seq_val: np.ndarray,
        X_tab_val: np.ndarray,
        y_val: np.ndarray
    ) -> Dict[str, Any]:
        """
        Trains all ML and DL components and calibrates the hybrid meta-learner.
        """
        training_logs = {}

        # 1. Train Deep Learning Base Learner
        print("[Hybrid] Training Deep Learning sequence model...")
        dl_hist = self.dl_trainer.train(
            X_seq_train, y_train,
            X_seq_val, y_val,
            epochs=self.cfg.dl_epochs,
            batch_size=self.cfg.dl_batch_size
        )
        training_logs['dl_history'] = dl_hist

        # 2. Train Tabular Machine Learning Models
        print("[Hybrid] Training XGBoost model...")
        self.xgb_model.fit(X_tab_train, y_train, eval_set=[(X_tab_val, y_val)])

        print("[Hybrid] Training LightGBM model...")
        self.lgb_model.fit(X_tab_train, y_train, eval_set=[(X_tab_val, y_val)])

        print("[Hybrid] Training Random Forest model...")
        self.rf_model.fit(X_tab_train, y_train)

        # 3. Mode A: Calibrate Stacking Meta-Learner using validation out-of-fold predictions
        p_dl_val = self.dl_trainer.predict_proba(X_seq_val)
        p_xgb_val = self.xgb_model.predict_proba(X_tab_val)
        p_lgb_val = self.lgb_model.predict_proba(X_tab_val)
        p_rf_val = self.rf_model.predict_proba(X_tab_val)

        # Construct Meta-Feature Matrix
        M_val = np.column_stack([p_dl_val, p_xgb_val, p_lgb_val, p_rf_val])
        self.meta_learner.fit(M_val, y_val)

        # 4. Mode B: Feature Fusion (Deep Latents + Tabular Indicators)
        print("[Hybrid] Extracting deep latent embeddings for Feature Fusion...")
        latents_train = self.dl_trainer.extract_latent_features(X_seq_train)
        latents_val = self.dl_trainer.extract_latent_features(X_seq_val)

        X_fused_train = np.hstack([X_tab_train, latents_train])
        X_fused_val = np.hstack([X_tab_val, latents_val])

        print("[Hybrid] Training Feature-Fused Gradient Boosted Model...")
        self.fusion_xgb.fit(X_fused_train, y_train, eval_set=[(X_fused_val, y_val)])

        # 5. Mode C: Adaptive Blending Weights based on validation AUC / Accuracy
        val_accs = {
            'dl': accuracy_score(y_val, (p_dl_val >= 0.5).astype(int)),
            'xgb': accuracy_score(y_val, (p_xgb_val >= 0.5).astype(int)),
            'lgb': accuracy_score(y_val, (p_lgb_val >= 0.5).astype(int)),
            'rf': accuracy_score(y_val, (p_rf_val >= 0.5).astype(int)),
        }
        # Softmax weighting
        exp_acc = {k: np.exp(v * 4.0) for k, v in val_accs.items()}
        sum_exp = sum(exp_acc.values())
        self.model_weights = {k: v / sum_exp for k, v in exp_acc.items()}

        self.is_fitted = True
        print(f"[Hybrid] Calibration complete. Adaptive weights: {self.model_weights}")
        return training_logs

    def predict_all_models(
        self,
        X_seq: np.ndarray,
        X_tab: np.ndarray
    ) -> Dict[str, np.ndarray]:
        """
        Generates probability predictions from all individual models and hybrid combinations.
        Returns dict of model_name -> probabilities array.
        """
        p_dl = self.dl_trainer.predict_proba(X_seq)
        p_xgb = self.xgb_model.predict_proba(X_tab)
        p_lgb = self.lgb_model.predict_proba(X_tab)
        p_rf = self.rf_model.predict_proba(X_tab)

        # 1. Stacking Meta-Learner prediction
        M = np.column_stack([p_dl, p_xgb, p_lgb, p_rf])
        p_stacking = self.meta_learner.predict_proba(M)[:, 1]

        # 2. Feature-Fusion model prediction
        latents = self.dl_trainer.extract_latent_features(X_seq)
        X_fused = np.hstack([X_tab, latents])
        p_fusion = self.fusion_xgb.predict_proba(X_fused)

        # 3. Adaptive Blended prediction
        p_blend = (
            self.model_weights['dl'] * p_dl +
            self.model_weights['xgb'] * p_xgb +
            self.model_weights['lgb'] * p_lgb +
            self.model_weights['rf'] * p_rf
        )

        # 4. Final Hybrid Consensus: ensemble of Stacking, Fusion, and Blend
        p_hybrid = (0.45 * p_stacking) + (0.35 * p_fusion) + (0.20 * p_blend)

        return {
            'Deep Learning (BiLSTM-Attn)': p_dl,
            'XGBoost': p_xgb,
            'LightGBM': p_lgb,
            'Random Forest': p_rf,
            'Hybrid (Stacking)': p_stacking,
            'Hybrid (Feature Fusion)': p_fusion,
            'Hybrid (Adaptive Blend)': p_blend,
            'Hybrid (Full Framework)': p_hybrid,
        }

    def evaluate(
        self,
        X_seq_test: np.ndarray,
        X_tab_test: np.ndarray,
        y_test: np.ndarray
    ) -> pd.DataFrame:
        """
        Evaluates all models on the held-out test dataset across quantitative classification metrics.
        """
        preds = self.predict_all_models(X_seq_test, X_tab_test)
        results = []

        for model_name, probas in preds.items():
            pred_class = (probas >= 0.5).astype(int)

            acc = accuracy_score(y_test, pred_class)
            prec = precision_score(y_test, pred_class, zero_division=0)
            rec = recall_score(y_test, pred_class, zero_division=0)
            f1 = f1_score(y_test, pred_class, zero_division=0)
            try:
                auc = roc_auc_score(y_test, probas)
            except Exception:
                auc = 0.5
            brier = brier_score_loss(y_test, probas)

            results.append({
                'Model': model_name,
                'Accuracy': round(acc, 4),
                'Precision': round(prec, 4),
                'Recall': round(rec, 4),
                'F1 Score': round(f1, 4),
                'ROC-AUC': round(auc, 4),
                'Brier Score': round(brier, 4)
            })

        df_results = pd.DataFrame(results).sort_values(by='F1 Score', ascending=False).reset_index(drop=True)
        return df_results
