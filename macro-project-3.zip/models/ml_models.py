"""
Tabular Machine Learning Models (XGBoost, LightGBM, Random Forest)
Unified interfaces for model training, probabilistic inference, and feature importance.
"""
from typing import Optional, Dict, Any, List
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from config import ModelConfig


class XGBoostModelWrapper:
    """Wrapper around XGBoost Classifier."""

    def __init__(self, config: Optional[ModelConfig] = None):
        self.cfg = config or ModelConfig()
        self.model = XGBClassifier(
            n_estimators=self.cfg.xgb_n_estimators,
            max_depth=self.cfg.xgb_max_depth,
            learning_rate=self.cfg.xgb_learning_rate,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=self.cfg.random_state,
            eval_metric="logloss",
            verbosity=0
        )

    def fit(self, X: np.ndarray, y: np.ndarray, eval_set: Optional[list] = None):
        if eval_set:
            self.model.fit(
                X, y,
                eval_set=eval_set,
                verbose=False
            )
        else:
            self.model.fit(X, y)
        return self

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        return self.model.predict_proba(X)[:, 1]

    def predict(self, X: np.ndarray, threshold: float = 0.5) -> np.ndarray:
        probs = self.predict_proba(X)
        return (probs >= threshold).astype(int)

    def get_feature_importances(self, feature_names: List[str]) -> pd.Series:
        importances = self.model.feature_importances_
        return pd.Series(importances, index=feature_names).sort_values(ascending=False)


class LightGBMModelWrapper:
    """Wrapper around LightGBM Classifier."""

    def __init__(self, config: Optional[ModelConfig] = None):
        self.cfg = config or ModelConfig()
        self.model = LGBMClassifier(
            n_estimators=self.cfg.lgb_n_estimators,
            max_depth=self.cfg.lgb_max_depth,
            learning_rate=self.cfg.lgb_learning_rate,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=self.cfg.random_state,
            verbose=-1
        )

    def fit(self, X: np.ndarray, y: np.ndarray, eval_set: Optional[list] = None):
        if eval_set and len(eval_set) > 0:
            val_X, val_y = eval_set[0]
            try:
                self.model.fit(X, y, eval_set=[(val_X, val_y)])
            except Exception:
                self.model.fit(X, y)
        else:
            self.model.fit(X, y)
        return self

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        return self.model.predict_proba(X)[:, 1]

    def predict(self, X: np.ndarray, threshold: float = 0.5) -> np.ndarray:
        probs = self.predict_proba(X)
        return (probs >= threshold).astype(int)

    def get_feature_importances(self, feature_names: List[str]) -> pd.Series:
        importances = self.model.feature_importances_
        # Normalize sum to 1
        total = np.sum(importances)
        norm_imp = importances / total if total > 0 else importances
        return pd.Series(norm_imp, index=feature_names).sort_values(ascending=False)


class RandomForestModelWrapper:
    """Wrapper around Random Forest Classifier."""

    def __init__(self, config: Optional[ModelConfig] = None):
        self.cfg = config or ModelConfig()
        self.model = RandomForestClassifier(
            n_estimators=self.cfg.rf_n_estimators,
            max_depth=8,
            min_samples_split=5,
            min_samples_leaf=2,
            random_state=self.cfg.random_state,
            n_jobs=-1
        )

    def fit(self, X: np.ndarray, y: np.ndarray, eval_set: Optional[list] = None):
        self.model.fit(X, y)
        return self

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        return self.model.predict_proba(X)[:, 1]

    def predict(self, X: np.ndarray, threshold: float = 0.5) -> np.ndarray:
        probs = self.predict_proba(X)
        return (probs >= threshold).astype(int)

    def get_feature_importances(self, feature_names: List[str]) -> pd.Series:
        importances = self.model.feature_importances_
        return pd.Series(importances, index=feature_names).sort_values(ascending=False)
