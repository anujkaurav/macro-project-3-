"""
Fast Interactive Project Demonstration Script
Hybrid ML-DL Framework for Time-Series Stock Market Trend Prediction and Technical Analysis
"""
import os
import sys
import time
import datetime
import pandas as pd
import numpy as np

if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

from config import ModelConfig, BacktestConfig
from data.loader import MarketDataLoader
from indicators.technical import TechnicalIndicatorEngine
from indicators.patterns import CandlestickPatternDetector
from indicators.signal_generator import TechnicalSignalGenerator
from data.preprocessor import MarketDataPreprocessor
from data.sequence_builder import TimeSeriesSequenceBuilder
from models.hybrid_framework import HybridFramework
from backtesting.engine import BacktestEngine
from explainability.interpreter import FrameworkInterpreter


def print_banner(text: str, width: int = 80):
    print("\n" + "=" * width)
    print(f" {text}")
    print("=" * width)


def print_section(title: str):
    print(f"\n--> {title}")
    print("-" * 60)


def run_presentation_demo(ticker: str = "AAPL"):
    start_time = time.time()
    print_banner(f"HYBRID ML-DL QUANTITATIVE STOCK MARKET FRAMEWORK - LIVE DEMO ({ticker})")
    print(f"Timestamp: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("Architectural Stack: BiLSTM-Attention + TCN + XGBoost + LightGBM + Stacking Meta-Learner")

    # Stage 1: Data Ingestion
    print_section("STAGE 1: Ingestion & Market Data Integrity")
    loader = MarketDataLoader()
    df_raw = loader.fetch_data(ticker=ticker, start_date="2021-01-01", end_date="2026-10-13")
    print(f"✓ Loaded {len(df_raw)} OHLCV daily market bars for {ticker}.")
    print(f"  Range: {df_raw.index.min().date()} to {df_raw.index.max().date()}")
    print(f"  Latest Close: ${df_raw['Close'].iloc[-1]:,.2f} | 20-Day Avg Volume: {int(df_raw['Volume'].rolling(20).mean().iloc[-1]):,}")

    # Stage 2: Technical Indicators & Candlestick Patterns
    print_section("STAGE 2: Multi-Modal Feature Engineering & Signal Generation")
    engine = TechnicalIndicatorEngine()
    df_ind = engine.compute_all(df_raw)
    df_patt = CandlestickPatternDetector.detect_all(df_ind)
    df_full = TechnicalSignalGenerator.generate_signals(df_patt)
    
    summary = TechnicalSignalGenerator.get_latest_summary(df_full)
    print(f"✓ Calculated 86 technical, volatility, momentum, and morphological indicators.")
    print(f"  - Technical Consensus Rating : {summary['rating']}")
    print(f"  - Consensus Score            : {summary['consensus_score']:+.3f} (Scale: -1.0 to +1.0)")
    print(f"  - Indicator Consensus        : {summary['bullish_signals']} Bullish | {summary['bearish_signals']} Bearish | {summary['neutral_signals']} Neutral")
    print(f"  - Latest Candlestick State   : Doji={int(df_full['Pattern_Doji'].iloc[-1])}, Hammer={int(df_full['Pattern_Hammer'].iloc[-1])}, Engulfing={int(df_full['Pattern_Bullish_Engulfing'].iloc[-1])}")

    # Stage 3: Chronological Splitting & Sequence Construction
    print_section("STAGE 3: Lookahead-Free Chronological Splitting & 3D Sequence Generation")
    model_cfg = ModelConfig(lookback_window=30, dl_epochs=8, dl_batch_size=32)
    preprocessor = MarketDataPreprocessor(model_cfg)
    features_df, target_clf, target_reg = preprocessor.prepare_dataset(df_full)
    splits = preprocessor.split_chronological(features_df, target_clf)

    X_train_df, y_train_s = splits['train']
    X_val_df, y_val_s = splits['val']
    X_test_df, y_test_s = splits['test']

    seq_builder = TimeSeriesSequenceBuilder(lookback_window=model_cfg.lookback_window)
    X_seq_train, X_tab_train, y_train, _ = seq_builder.build_sequences(X_train_df, y_train_s)
    X_seq_val, X_tab_val, y_val, _ = seq_builder.build_sequences(X_val_df, y_val_s)
    X_seq_test, X_tab_test, y_test, dates_test = seq_builder.build_sequences(X_test_df, y_test_s)

    print(f"✓ Split Chronology: Train={len(X_seq_train)} | Val={len(X_seq_val)} | Test={len(X_seq_test)}")
    print(f"✓ 3D Tensor Dimensions (PyTorch DL) : {X_seq_train.shape} (Batch, Lookback, Features)")
    print(f"✓ 2D Matrix Dimensions (Tabular ML)  : {X_tab_train.shape} (Batch, Features)")
    print(f"✓ Strict temporal ordering enforced: No future lookahead leakage.")

    # Stage 4: Model Training & Hybrid Ensemble
    print_section("STAGE 4: Deep Learning & Machine Learning Hybrid Synthesis")
    hybrid = HybridFramework(model_cfg)
    hybrid.train(X_seq_train, X_tab_train, y_train, X_seq_val, X_tab_val, y_val)
    print("✓ Deep Learning (BiLSTM + Attention) trained with AdamW & Early Stopping.")
    print("✓ Tree Ensembles (XGBoost, LightGBM, Random Forest) fitted on stationary features.")
    print("✓ Deep Latent Embeddings (32-dim) fused with tabular features for Feature-Fusion model.")
    print("✓ Stacking Meta-Learner (Logistic Regression) calibrated on validation probabilities.")

    # Stage 5: Out-of-Sample Performance Evaluation
    print_section("STAGE 5: Out-of-Sample Model Benchmarking (Held-Out Test Set)")
    eval_df = hybrid.evaluate(X_seq_test, X_tab_test, y_test)
    print(eval_df.to_string(index=False))

    # Stage 6: Backtesting Simulation
    print_section("STAGE 6: Quantitative Financial Strategy Backtest (Realistic Execution)")
    bt_cfg = BacktestConfig(confidence_threshold=0.51)
    all_preds = hybrid.predict_all_models(X_seq_test, X_tab_test)
    hybrid_probs = all_preds['Hybrid (Full Framework)']

    backtester = BacktestEngine(bt_cfg)
    history_df, bt_metrics = backtester.run_backtest(df_full, hybrid_probs, dates_test, allow_short=True)

    for k, v in bt_metrics.items():
        print(f"  {k:<32}: {v}")

    # Stage 7: Explainable AI & Directional Forecast
    print_section("STAGE 7: Explainable AI (XAI) & Actionable Market Intelligence")
    interpreter = FrameworkInterpreter(hybrid, feature_names=preprocessor.feature_columns)
    latest_explanation = interpreter.explain_prediction(
        X_seq_sample=X_seq_test[-1],
        X_tab_sample=X_tab_test[-1],
        sample_date=str(dates_test[-1].date()),
        price_row=df_full.loc[dates_test[-1]]
    )

    print(f"  Analysis Date               : {latest_explanation['date']}")
    print(f"  Predicted Directional Bias  : {latest_explanation['sentiment']}")
    print(f"  Hybrid Model Upward Prob.   : {latest_explanation['hybrid_probability'] * 100:.1f}%")
    print(f"  Top Salient Features        : {list(latest_explanation['salient_features'].keys())[:5]}")

    elapsed = round(time.time() - start_time, 2)
    print_banner(f"DEMO COMPLETED IN {elapsed}s - ALL SYSTEMS OPERATIONAL")
    print("To open the interactive visual dashboard, run:")
    print("   streamlit run app/dashboard.py")
    print("Or double-click RUN_DASHBOARD.bat")


if __name__ == "__main__":
    ticker_arg = sys.argv[1] if len(sys.argv) > 1 else "AAPL"
    run_presentation_demo(ticker=ticker_arg)
