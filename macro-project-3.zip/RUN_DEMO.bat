@echo off
title Hybrid ML-DL Stock Market Trend Prediction - Interactive Demo
color 0E
echo ===============================================================================
echo   HYBRID ML-DL STOCK MARKET TREND PREDICTION & TECHNICAL ANALYSIS
echo   Starting Interactive Demo Application...
echo ===============================================================================
echo.

cd /d "%~dp0"

if exist "C:\ProgramData\anaconda3\python.exe" (
    set "PYTHON_EXE=C:\ProgramData\anaconda3\python.exe"
) else (
    set "PYTHON_EXE=python"
)

"%PYTHON_EXE%" demo.py

pause
