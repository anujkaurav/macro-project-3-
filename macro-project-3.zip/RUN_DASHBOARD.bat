@echo off
title Hybrid ML-DL Stock Market Trend Prediction - Interactive Dashboard
color 0A
echo ===============================================================================
echo   HYBRID ML-DL STOCK MARKET TREND PREDICTION & TECHNICAL ANALYSIS
echo   Launching Interactive Quantitative Dashboard...
echo ===============================================================================
echo.

cd /d "%~dp0"

echo [1/2] Checking Python and Streamlit environment...
if exist "C:\ProgramData\anaconda3\python.exe" (
    set "PYTHON_EXE=C:\ProgramData\anaconda3\python.exe"
) else (
    set "PYTHON_EXE=python"
)

echo [2/2] Starting Streamlit Web App on http://localhost:8501 ...
echo Press Ctrl+C in this window when you wish to stop the server.
echo.

"%PYTHON_EXE%" -m streamlit run app/dashboard.py

pause
