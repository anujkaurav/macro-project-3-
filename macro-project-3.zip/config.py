"""
Global Configuration for Hybrid ML-DL Stock Market Trend Prediction Framework
"""
from dataclasses import dataclass, field
from typing import List, Optional, Tuple
import os

@dataclass
class IndicatorConfig:
    """Parameters for technical indicator computation."""
    sma_periods: List[int] = field(default_factory=lambda: [10, 20, 50, 200])
    ema_periods: List[int] = field(default_factory=lambda: [9, 12, 21, 26, 50])
    rsi_period: int = 14
    macd_fast: int = 12
    macd_slow: int = 26
    macd_signal: int = 9
    bb_period: int = 20
    bb_std: float = 2.0
    atr_period: int = 14
    stoch_k: int = 14
    stoch_d: int = 3
    adx_period: int = 14
    cci_period: int = 20
    mfi_period: int = 14
    supertrend_period: int = 10
    supertrend_multiplier: float = 3.0

@dataclass
class ModelConfig:
    """Hyperparameters for ML, DL, and Hybrid architectures."""
    # Sequence / Time series settings
    lookback_window: int = 30           # Number of historical days fed into DL models
    forecast_horizon: int = 1           # Days ahead to predict trend (e.g. 1-day or 5-day)
    classification_threshold: float = 0.001 # Minimum return threshold for Up (+1) vs Down (0 or -1)
    task_type: str = "classification"   # "classification" (Up/Down) or "regression" (Return)
    
    # Deep Learning (PyTorch)
    hidden_dim: int = 64
    num_layers: int = 2
    dropout: float = 0.2
    bidirectional: bool = True
    attention_heads: int = 4
    learning_rate: float = 0.001
    dl_epochs: int = 35
    dl_batch_size: int = 32
    weight_decay: float = 1e-4
    dl_model_type: str = "bilstm_attention"  # "bilstm_attention", "tcn_transformer", "gru"
    
    # Machine Learning (XGBoost / LightGBM / RF)
    xgb_n_estimators: int = 150
    xgb_max_depth: int = 5
    xgb_learning_rate: float = 0.05
    lgb_n_estimators: int = 150
    lgb_max_depth: int = 5
    lgb_learning_rate: float = 0.05
    rf_n_estimators: int = 100
    
    # Hybrid Stacking / Blending
    fusion_strategy: str = "stacking"   # "stacking", "feature_fusion", "adaptive_blend"
    meta_learner: str = "logistic"      # "logistic", "ridge", "xgboost"
    
    # Training / Walk-Forward Split
    train_ratio: float = 0.70
    val_ratio: float = 0.15
    test_ratio: float = 0.15
    random_state: int = 42

@dataclass
class BacktestConfig:
    """Configuration for quantitative backtesting simulation."""
    initial_capital: float = 100_000.0
    commission_rate: float = 0.0005     # 5 bps per trade
    slippage: float = 0.0002            # 2 bps slippage
    position_sizing: str = "fixed_fractional" # "all_in", "fixed_fractional", "volatility_parity"
    risk_fraction: float = 0.95         # Fraction of capital allocated when in position
    confidence_threshold: float = 0.55  # Minimum model confidence to execute trade

@dataclass
class AppConfig:
    """Global framework execution configuration."""
    ticker: str = "AAPL"
    start_date: str = "2020-01-01"
    end_date: Optional[str] = None
    cache_dir: str = os.path.join(os.path.dirname(__file__), "data_cache")
    model_save_dir: str = os.path.join(os.path.dirname(__file__), "saved_models")
    indicator_cfg: IndicatorConfig = field(default_factory=IndicatorConfig)
    model_cfg: ModelConfig = field(default_factory=ModelConfig)
    backtest_cfg: BacktestConfig = field(default_factory=BacktestConfig)
