"""
Model Interpretability and Technical Rationale Generator
Synthesizes feature importance, attention weights, and technical indicators into actionable insights.
"""
from typing import Dict, Any, List, Optional
import numpy as np
import pandas as pd
from models.hybrid_framework import HybridFramework


class FrameworkInterpreter:
    """
    Extracts multi-modal interpretability across tree ensembles,
    neural temporal attention mechanisms, and technical indicator states.
    """

    def __init__(self, hybrid_framework: HybridFramework, feature_names: List[str]):
        self.framework = hybrid_framework
        self.feature_names = feature_names

    def get_aggregated_feature_importances(self, top_n: int = 15) -> pd.DataFrame:
        """
        Combines feature importances from XGBoost, LightGBM, and Random Forest.
        """
        xgb_imp = self.framework.xgb_model.get_feature_importances(self.feature_names)
        lgb_imp = self.framework.lgb_model.get_feature_importances(self.feature_names)
        rf_imp = self.framework.rf_model.get_feature_importances(self.feature_names)

        df_imp = pd.DataFrame({
            'XGBoost': xgb_imp,
            'LightGBM': lgb_imp,
            'Random_Forest': rf_imp
        }).fillna(0.0)

        # Normalized composite score
        df_imp['Composite_Importance'] = (
            0.40 * df_imp['XGBoost'] +
            0.35 * df_imp['LightGBM'] +
            0.25 * df_imp['Random_Forest']
        )
        return df_imp.sort_values('Composite_Importance', ascending=False).head(top_n)

    def get_attention_profile(self, X_seq: np.ndarray) -> np.ndarray:
        """
        Extracts temporal attention weights from BiLSTM-Attention model.
        Returns array of shape (samples, lookback_window).
        """
        return self.framework.dl_trainer.get_attention_weights(X_seq)

    def explain_prediction(
        self,
        X_seq_sample: np.ndarray,
        X_tab_sample: np.ndarray,
        sample_date: str,
        price_row: pd.Series
    ) -> Dict[str, Any]:
        """
        Generates an end-to-end multi-layer explanation for a specific prediction day.
        """
        # Ensure 2D/3D shapes for single sample
        if X_seq_sample.ndim == 2:
            X_seq_sample = np.expand_dims(X_seq_sample, axis=0)
        if X_tab_sample.ndim == 1:
            X_tab_sample = np.expand_dims(X_tab_sample, axis=0)

        all_preds = self.framework.predict_all_models(X_seq_sample, X_tab_sample)
        sample_preds = {k: round(float(v[0]), 4) for k, v in all_preds.items()}

        attn_weights = self.framework.dl_trainer.get_attention_weights(X_seq_sample)[0]

        # Top driving features for this sample
        feat_series = pd.Series(X_tab_sample[0], index=self.feature_names)
        top_features = feat_series.abs().sort_values(ascending=False).head(8).to_dict()

        # Hybrid direction determination
        hybrid_p = sample_preds['Hybrid (Full Framework)']
        if hybrid_p >= 0.60:
            sentiment = "Bullish (Strong Buy)"
        elif hybrid_p >= 0.52:
            sentiment = "Mildly Bullish (Cautious Buy)"
        elif hybrid_p <= 0.40:
            sentiment = "Bearish (Strong Sell)"
        elif hybrid_p <= 0.48:
            sentiment = "Mildly Bearish (Cautious Sell)"
        else:
            sentiment = "Neutral / Sideways"

        return {
            'date': sample_date,
            'sentiment': sentiment,
            'hybrid_probability': hybrid_p,
            'model_breakdown': sample_preds,
            'temporal_attention': attn_weights.tolist(),
            'salient_features': {k: round(float(v), 3) for k, v in top_features.items()}
        }
