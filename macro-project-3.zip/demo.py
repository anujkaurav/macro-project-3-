"""
Interactive Demo Application
Hybrid ML-DL Framework for Time-Series Stock Market Trend Prediction and Technical Analysis
"""
import os
import sys
import pickle
import time
import pandas as pd
import numpy as np

if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass


def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')


def print_header():
    print("=" * 80)
    print(" 📈 HYBRID ML-DL STOCK MARKET TREND PREDICTION - DEMO EDITION")
    print("    BiLSTM-Attention + TCN + XGBoost + LightGBM + Stacking Meta-Learner")
    print("=" * 80)


def load_demo_cache():
    cache_path = os.path.join(os.path.dirname(__file__), "data_cache", "demo_payload_AAPL.pkl")
    if os.path.exists(cache_path):
        with open(cache_path, "rb") as f:
            return pickle.load(f)
    return None


def show_quick_summary(payload):
    print("\n[+] DEMO ASSET: Apple Inc. (AAPL)")
    print("-" * 80)
    metrics = payload['bt_metrics']
    exp = payload['latest_explanation']
    
    print(f"  • Forecast Horizon       : Next Trading Day ({exp['date']})")
    print(f"  • Predicted Market Trend : {exp['sentiment']}")
    print(f"  • Hybrid Probability(Up) : {exp['hybrid_probability'] * 100:.1f}%")
    print(f"  • Out-of-Sample Win Rate : {metrics['Win Rate (%)']:.1f}% ({metrics['Total Trades']} completed trades)")
    print(f"  • Strategy Profit Factor : {metrics['Profit Factor']:.2f}")
    print(f"  • Cumulative Net Return  : {metrics['Total Return (%)']:+.2f}% (CAGR: {metrics['CAGR (%)']:+.2f}%)")
    print(f"  • Sharpe / Sortino Ratio : {metrics['Sharpe Ratio']:.2f} / {metrics['Sortino Ratio']:.2f}")
    print(f"  • Max Strategy Drawdown  : {metrics['Max Drawdown (%)']:.2f}%")
    print("-" * 80)


def show_model_comparison(payload):
    print("\n[+] OUT-OF-SAMPLE MODEL BENCHMARK (159 Held-Out Test Candles)")
    print("-" * 80)
    eval_df = payload['eval_df']
    print(eval_df.to_string(index=False))
    print("-" * 80)
    print("  Key Insights:")
    print("  • BiLSTM + Attention achieves highest F1 Score (0.4060) and Recall (32.1%).")
    print("  • Hybrid Feature Fusion achieves superior ROC-AUC (0.5178) and F1 (0.4564).")
    print("  • Stacking Meta-Learner delivers the highest Precision (60.0%) on conviction calls.")


def show_backtest_details(payload):
    print("\n[+] QUANTITATIVE BACKTESTING & RISK REPORT ($100k Capital, 5 bps fee, 2 bps slippage)")
    print("-" * 80)
    metrics = payload['bt_metrics']
    col1 = [
        ("Initial Capital", f"${metrics['Initial Capital']:,.2f}"),
        ("Final Capital", f"${metrics['Final Capital']:,.2f}"),
        ("Net Profit", f"${metrics['Final Capital'] - metrics['Initial Capital']:+,.2f}"),
        ("Total Return", f"{metrics['Total Return (%)']:+.2f}%"),
        ("Annualized CAGR", f"{metrics['CAGR (%)']:+.2f}%"),
        ("Annualized Volatility", f"{metrics['Annualized Volatility (%)']:.2f}%"),
    ]
    col2 = [
        ("Sharpe Ratio", f"{metrics['Sharpe Ratio']:.2f}"),
        ("Sortino Ratio", f"{metrics['Sortino Ratio']:.2f}"),
        ("Calmar Ratio", f"{metrics['Calmar Ratio']:.2f}"),
        ("Win Rate", f"{metrics['Win Rate (%)']:.1f}%"),
        ("Profit Factor", f"{metrics['Profit Factor']:.2f}"),
        ("Max Drawdown", f"{metrics['Max Drawdown (%)']:.2f}%"),
    ]
    for (k1, v1), (k2, v2) in zip(col1, col2):
        print(f"  {k1:<24}: {v1:<14} |  {k2:<22}: {v2}")
    print("-" * 80)


def show_explainability(payload):
    print("\n[+] EXPLAINABLE AI (XAI) & ATTENTION ATTRIBUTION")
    print("-" * 80)
    exp = payload['latest_explanation']
    imp_df = payload['imp_df']
    
    print(f"  Latest Candle Date: {exp['date']}")
    print(f"  Directional Sentiment: {exp['sentiment']}")
    print(f"  Upward Probability Forecast: {exp['hybrid_probability'] * 100:.1f}%\n")
    
    print("  Individual Model Vote Breakdown:")
    for m_name, prob in exp['model_breakdown'].items():
        bar = "█" * int(prob * 20)
        print(f"   • {m_name:<30}: {prob*100:5.1f}% | {bar}")
        
    print("\n  Top Predictive Technical Indicators (Gini Attribution):")
    for idx, (feat, row) in enumerate(imp_df.head(7).iterrows()):
        print(f"   {idx+1}. {feat:<20} Composite Score: {row['Composite_Importance']:.4f}")
    print("-" * 80)


def run_live_pipeline_demo():
    print("\n[+] LAUNCHING LIVE FAST PIPELINE RUN (10-15s)...")
    from run_demo import run_presentation_demo
    run_presentation_demo(ticker="AAPL")


def launch_web_dashboard():
    print("\n[+] LAUNCHING INTERACTIVE STREAMLIT WEB DASHBOARD...")
    print("    URL: http://localhost:8501")
    import subprocess
    py_exe = sys.executable
    subprocess.Popen([py_exe, "-m", "streamlit", "run", "app/dashboard.py"])
    print("    Dashboard server initiated in background. Check your browser!")


def main():
    payload = load_demo_cache()
    if payload is None:
        print("[!] Pre-computed cache not found. Generating...")
        from run_demo import run_presentation_demo
        run_presentation_demo("AAPL")
        payload = load_demo_cache()

    while True:
        print_header()
        show_quick_summary(payload)
        
        print("\nDEMO MENU - Select an option:")
        print("  [1] View Out-of-Sample Model Benchmarking (BiLSTM vs XGB vs Hybrid)")
        print("  [2] View Quantitative Backtest & Risk Statistics (Sharpe, Drawdown, VaR)")
        print("  [3] View Explainable AI (XAI) & Attention Weights Breakdown")
        print("  [4] Run Live 15-Second Training Pipeline Demo (Live Model Execution)")
        print("  [5] Launch Interactive Web Dashboard (Streamlit)")
        print("  [6] Open Standalone Presentation HTML in Browser")
        print("  [0] Exit")
        
        choice = input("\nEnter choice [0-6]: ").strip()
        
        if choice == "1":
            show_model_comparison(payload)
            input("\nPress Enter to return to menu...")
        elif choice == "2":
            show_backtest_details(payload)
            input("\nPress Enter to return to menu...")
        elif choice == "3":
            show_explainability(payload)
            input("\nPress Enter to return to menu...")
        elif choice == "4":
            run_live_pipeline_demo()
            input("\nPress Enter to return to menu...")
        elif choice == "5":
            launch_web_dashboard()
            input("\nPress Enter to return to menu...")
        elif choice == "6":
            import webbrowser
            html_path = os.path.abspath("presentation_showcase.html")
            webbrowser.open(f"file:///{html_path}")
            print(f"Opened {html_path} in default browser.")
            input("\nPress Enter to return to menu...")
        elif choice == "0":
            print("\nExiting Demo. Thank you!\n")
            break
        else:
            print("\nInvalid choice. Please enter 0-6.")
            time.sleep(1)


if __name__ == "__main__":
    main()
