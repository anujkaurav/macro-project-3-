"""
Interactive Streamlit Web Dashboard
Hybrid ML-DL Framework for Time-Series Stock Market Trend Prediction and Technical Analysis
"""
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import streamlit as st
import numpy as np
import pandas as pd
import datetime

from config import AppConfig, IndicatorConfig, ModelConfig, BacktestConfig
from data.loader import MarketDataLoader
from indicators.technical import TechnicalIndicatorEngine
from indicators.patterns import CandlestickPatternDetector
from indicators.signal_generator import TechnicalSignalGenerator
from data.preprocessor import MarketDataPreprocessor
from data.sequence_builder import TimeSeriesSequenceBuilder
from models.hybrid_framework import HybridFramework
from backtesting.engine import BacktestEngine
from explainability.interpreter import FrameworkInterpreter
from visualization.plots import (
    plot_candlestick_with_indicators,
    plot_equity_curve,
    plot_model_comparison,
    plot_attention_heatmap,
    plot_feature_importance
)

# Page configuration
st.set_page_config(
    page_title="Hybrid ML-DL Quantitative Stock Predictor",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Styling
st.markdown("""
<style>
    .metric-card {
        background-color: #1e1e2f;
        border-radius: 8px;
        padding: 16px;
        border: 1px solid #2e2e42;
    }
    .stTabs [data-baseweb="tab-list"] {
        gap: 24px;
    }
    .stTabs [data-baseweb="tab"] {
        font-size: 16px;
        font-weight: 600;
    }
</style>
""", unsafe_allow_html=True)


@st.cache_data(show_spinner=False)
def load_and_process_stock_data(ticker: str, start_date: str, end_date: str):
    """Fetches data and calculates all technical indicators and patterns."""
    loader = MarketDataLoader()
    df_raw = loader.fetch_data(ticker=ticker, start_date=start_date, end_date=end_date)
    
    ind_engine = TechnicalIndicatorEngine()
    df_ind = ind_engine.compute_all(df_raw)
    
    df_patt = CandlestickPatternDetector.detect_all(df_ind)
    df_full = TechnicalSignalGenerator.generate_signals(df_patt)
    
    return df_full


def run_hybrid_pipeline(df_full: pd.DataFrame, model_cfg: ModelConfig, backtest_cfg: BacktestConfig, allow_short: bool = True):
    """Runs data sequence splitting, ML-DL model training, and quantitative backtest."""
    preprocessor = MarketDataPreprocessor(model_cfg)
    features_df, target_clf, target_reg = preprocessor.prepare_dataset(df_full)
    
    splits = preprocessor.split_chronological(features_df, target_clf)
    X_train_df, y_train_s = splits['train']
    X_val_df, y_val_s = splits['val']
    X_test_df, y_test_s = splits['test']
    
    seq_builder = TimeSeriesSequenceBuilder(lookback_window=model_cfg.lookback_window)
    X_seq_train, X_tab_train, y_seq_train, _ = seq_builder.build_sequences(X_train_df, y_train_s)
    X_seq_val, X_tab_val, y_seq_val, _ = seq_builder.build_sequences(X_val_df, y_val_s)
    X_seq_test, X_tab_test, y_seq_test, dates_test = seq_builder.build_sequences(X_test_df, y_test_s)
    
    # Train Hybrid Framework
    hybrid = HybridFramework(model_cfg)
    hybrid.train(
        X_seq_train, X_tab_train, y_seq_train,
        X_seq_val, X_tab_val, y_seq_val
    )
    
    # Evaluate across test set
    eval_df = hybrid.evaluate(X_seq_test, X_tab_test, y_seq_test)
    
    # Predictions
    all_preds = hybrid.predict_all_models(X_seq_test, X_tab_test)
    hybrid_probs = all_preds['Hybrid (Full Framework)']
    
    # Backtest
    backtester = BacktestEngine(backtest_cfg)
    history_df, bt_metrics = backtester.run_backtest(
        price_df=df_full,
        probabilities=hybrid_probs,
        dates=dates_test,
        allow_short=allow_short
    )
    
    # Explainability
    interpreter = FrameworkInterpreter(hybrid, feature_names=preprocessor.feature_columns)
    imp_df = interpreter.get_aggregated_feature_importances(top_n=15)
    attn_weights = interpreter.get_attention_profile(X_seq_test)
    
    # Latest sample explanation
    latest_explanation = interpreter.explain_prediction(
        X_seq_sample=X_seq_test[-1],
        X_tab_sample=X_tab_test[-1],
        sample_date=str(dates_test[-1].date()),
        price_row=df_full.loc[dates_test[-1]]
    )
    
    return {
        'eval_df': eval_df,
        'bt_metrics': bt_metrics,
        'history_df': history_df,
        'all_preds': all_preds,
        'dates_test': dates_test,
        'imp_df': imp_df,
        'attn_weights': attn_weights,
        'latest_explanation': latest_explanation,
        'feature_names': preprocessor.feature_columns
    }


# ==================== SIDEBAR ====================
st.sidebar.title("⚙️ Control Panel")
st.sidebar.markdown("### Asset & Time Horizon")

preset_tickers = ["AAPL", "NVDA", "MSFT", "TSLA", "SPY", "QQQ", "BTC-USD", "CUSTOM"]
selected_preset = st.sidebar.selectbox("Select Asset Ticker", preset_tickers, index=0)

if selected_preset == "CUSTOM":
    ticker = st.sidebar.text_input("Enter Ticker Symbol", value="AMZN").upper().strip()
else:
    ticker = selected_preset

col_s1, col_s2 = st.sidebar.columns(2)
with col_s1:
    start_date = st.date_input("Start Date", datetime.date(2021, 1, 1)).strftime("%Y-%m-%d")
with col_s2:
    end_date = st.date_input("End Date", datetime.date.today()).strftime("%Y-%m-%d")

st.sidebar.markdown("---")
st.sidebar.markdown("### Model Architecture Settings")
dl_type = st.sidebar.selectbox(
    "Deep Learning Backbone",
    ["bilstm_attention", "tcn_transformer"],
    format_func=lambda x: "BiLSTM + Temporal Attention" if x == "bilstm_attention" else "TCN + Transformer Encoder"
)

lookback = st.sidebar.slider("Lookback Window (Days)", min_value=10, max_value=60, value=30, step=5)
epochs = st.sidebar.slider("DL Training Epochs", min_value=10, max_value=50, value=25, step=5)

st.sidebar.markdown("---")
st.sidebar.markdown("### Quantitative Execution")
conf_thresh = st.sidebar.slider("Signal Confidence Threshold", min_value=0.50, max_value=0.70, value=0.52, step=0.01)
allow_short = st.sidebar.checkbox("Allow Short Positions", value=True)
comm_bps = st.sidebar.number_input("Commission (bps)", min_value=0.0, max_value=50.0, value=5.0, step=1.0) / 10000.0
slippage_bps = st.sidebar.number_input("Slippage (bps)", min_value=0.0, max_value=50.0, value=2.0, step=1.0) / 10000.0

run_button = st.sidebar.button("🚀 Train & Run Hybrid Framework", use_container_width=True, type="primary")

# Title Banner
st.title("📈 Hybrid ML-DL Stock Market Trend Prediction & Technical Analysis")
st.caption("Integrated Framework: BiLSTM Attention / TCN-Transformer + XGBoost + LightGBM + Meta-Learner Stacking + Vectorized Backtesting")

# Load Market Data
with st.spinner(f"Loading market data & calculating indicators for {ticker}..."):
    try:
        df_full = load_and_process_stock_data(ticker, start_date, end_date)
    except Exception as e:
        st.error(f"Failed to fetch data for {ticker}: {e}")
        st.stop()

# Header Metrics Row
latest_price = df_full['Close'].iloc[-1]
prev_price = df_full['Close'].iloc[-2]
day_change = (latest_price / prev_price - 1.0) * 100
latest_vol = df_full['Volume'].iloc[-1]
tech_summary = TechnicalSignalGenerator.get_latest_summary(df_full)

m_c1, m_c2, m_c3, m_c4, m_c5 = st.columns(5)
with m_c1:
    st.metric(f"{ticker} Current Price", f"${latest_price:,.2f}", f"{day_change:+.2f}%")
with m_c2:
    st.metric("Latest Volume", f"{latest_vol:,.0f}")
with m_c3:
    st.metric("Technical Rating", tech_summary['rating'], f"Score: {tech_summary['consensus_score']:+.2f}")
with m_c4:
    st.metric("Bullish Indicators", f"{tech_summary['bullish_signals']} / {tech_summary['bullish_signals'] + tech_summary['bearish_signals'] + tech_summary['neutral_signals']}")
with m_c5:
    st.metric("Bearish Indicators", f"{tech_summary['bearish_signals']}")

# Tabs Navigation
tab1, tab2, tab3, tab4 = st.tabs([
    "📊 Market & Technical Analysis",
    "🧠 Hybrid Model Benchmarking",
    "💰 Quantitative Backtesting",
    "🔍 Explainability & AI Insights"
])

# ==================== TAB 1: TECHNICAL ANALYSIS ====================
with tab1:
    st.subheader(f"Interactive Technical Analysis ({ticker})")
    
    # Candlestick Chart
    fig_candle = plot_candlestick_with_indicators(df_full.iloc[-250:], title=f"{ticker} Recent Price Action & Overlays")
    st.plotly_chart(fig_candle, use_container_width=True)
    
    # Detailed Indicator State Matrix
    st.subheader("Indicator Signal Breakdown")
    sig_cols = [c for c in df_full.columns if c.startswith('Signal_')]
    last_signals = {
        c.replace('Signal_', '').replace('_', ' '): "🟢 Bullish" if df_full[c].iloc[-1] > 0 else ("🔴 Bearish" if df_full[c].iloc[-1] < 0 else "⚪ Neutral")
        for c in sig_cols
    }
    
    # Display in 4 grid columns
    sig_grid = st.columns(4)
    for idx, (ind_name, state) in enumerate(last_signals.items()):
        with sig_grid[idx % 4]:
            st.info(f"**{ind_name}**: {state}")

import pickle

# Check for precomputed demo payload on startup
cache_demo_file = os.path.join(os.path.dirname(__file__), "..", "data_cache", f"demo_payload_{ticker}.pkl")
if 'pipeline_result' not in st.session_state and os.path.exists(cache_demo_file) and ticker == "AAPL":
    try:
        with open(cache_demo_file, "rb") as f:
            st.session_state['pipeline_result'] = pickle.load(f)
            st.session_state['curr_ticker'] = ticker
            st.session_state['is_demo_cache'] = True
    except Exception:
        pass

# Handle Model Execution
if run_button or ('pipeline_result' in st.session_state and st.session_state.get('curr_ticker') == ticker):
    if run_button:
        with st.spinner("Training Deep Learning, Machine Learning & Stacking Meta-Learners..."):
            m_cfg = ModelConfig(
                lookback_window=lookback,
                dl_model_type=dl_type,
                dl_epochs=epochs
            )
            bt_cfg = BacktestConfig(
                confidence_threshold=conf_thresh,
                commission_rate=comm_bps,
                slippage=slippage_bps
            )
            result = run_hybrid_pipeline(df_full, m_cfg, bt_cfg, allow_short=allow_short)
            st.session_state['pipeline_result'] = result
            st.session_state['curr_ticker'] = ticker
            st.session_state['is_demo_cache'] = False

    res = st.session_state['pipeline_result']
    
    if st.session_state.get('is_demo_cache'):
        st.info("✨ **Presentation Showcase Mode Active**: Viewing pre-calibrated benchmark on AAPL (Zero-Wait Instant Demo). Click **'Train & Run Hybrid Framework'** in the sidebar anytime for custom live training.")

    # ==================== TAB 2: MODEL BENCHMARKING ====================
    with tab2:
        st.subheader("Predictive Performance Across Architectures (Test Set)")
        
        # Performance Comparison Table
        eval_df = res['eval_df']
        st.dataframe(
            eval_df.style.highlight_max(subset=['Accuracy', 'Precision', 'F1 Score', 'ROC-AUC'], color='#2e7d32')
                         .highlight_min(subset=['Brier Score'], color='#1565c0'),
            use_container_width=True
        )
        
        # Interactive Performance Bar Chart
        fig_comp = plot_model_comparison(eval_df)
        st.plotly_chart(fig_comp, use_container_width=True)
        
        # Summary description
        st.markdown("""
        **Architecture Analysis**:
        - **Deep Learning (BiLSTM / TCN)** excels at capturing non-linear sequential dependencies and temporal autocorrelation.
        - **Gradient Boosted Trees (XGBoost & LightGBM)** offer sharp decision splits across stationary indicator distributions.
        - **Hybrid Synthesis (Stacking & Feature Fusion)** synergistically unites both paradigms, achieving superior F1 Score and calibration stability.
        """)

    # ==================== TAB 3: BACKTESTING ====================
    with tab3:
        st.subheader("Quantitative Strategy Simulation (Out-Of-Sample Test Set)")
        
        bt_metrics = res['bt_metrics']
        b_c1, b_c2, b_c3, b_c4, b_c5 = st.columns(5)
        with b_c1:
            st.metric("Hybrid Strategy Return", f"{bt_metrics['Total Return (%)']:+.2f}%", f"CAGR: {bt_metrics['CAGR (%)']:+.2f}%")
        with b_c2:
            st.metric("Benchmark (Buy & Hold)", f"{bt_metrics['Benchmark Return (%)']:+.2f}%")
        with b_c3:
            st.metric("Sharpe Ratio", f"{bt_metrics['Sharpe Ratio']:.2f}", f"Bench: {bt_metrics['Benchmark Sharpe']:.2f}")
        with b_c4:
            st.metric("Max Drawdown", f"{bt_metrics['Max Drawdown (%)']:.2f}%")
        with b_c5:
            st.metric("Win Rate / Profit Factor", f"{bt_metrics['Win Rate (%)']:.1f}%", f"PF: {bt_metrics['Profit Factor']:.2f}")
        
        # Equity Curve Chart
        fig_equity = plot_equity_curve(res['history_df'], bt_metrics, title=f"{ticker} Hybrid Quantitative Strategy vs Benchmark")
        st.plotly_chart(fig_equity, use_container_width=True)
        
        # Additional Risk Stats
        with st.expander("Detailed Risk & Trade Statistics"):
            col_r1, col_r2 = st.columns(2)
            with col_r1:
                st.write(f"- **Sortino Ratio**: {bt_metrics['Sortino Ratio']}")
                st.write(f"- **Calmar Ratio**: {bt_metrics['Calmar Ratio']}")
                st.write(f"- **Annualized Volatility**: {bt_metrics['Annualized Volatility (%)']}%")
            with col_r2:
                st.write(f"- **Daily Value at Risk (VaR 95%)**: {bt_metrics['Daily VaR 95% (%)']}%")
                st.write(f"- **Daily Expected Shortfall (CVaR 95%)**: {bt_metrics['Daily CVaR 95% (%)']}%")
                st.write(f"- **Total Executed Trades**: {bt_metrics['Total Trades']}")

    # ==================== TAB 4: EXPLAINABILITY ====================
    with tab4:
        st.subheader("Multi-Modal Decision Rationale & Interpretability")
        
        latest_exp = res['latest_explanation']
        
        # High-Conviction Signal Alert
        p_val = latest_exp['hybrid_probability']
        st.markdown(f"""
        ### Signal for {latest_exp['date']}: **{latest_exp['sentiment']}**
        **Hybrid Upward Probability**: `{p_val * 100:.1f}%`
        """)
        
        e_col1, e_col2 = st.columns(2)
        with e_col1:
            st.markdown("#### Top Predictive Technical Indicators")
            fig_imp = plot_feature_importance(res['imp_df'])
            st.plotly_chart(fig_imp, use_container_width=True)
            
        with e_col2:
            st.markdown("#### BiLSTM Temporal Attention Distribution")
            fig_attn = plot_attention_heatmap(res['attn_weights'], title="Temporal Lookback Attention Weights")
            st.plotly_chart(fig_attn, use_container_width=True)
            
        st.markdown("#### Model Probability Breakdown for Latest Candle")
        st.json(latest_exp['model_breakdown'])

else:
    with tab2:
        st.info("👈 Click **'Train & Run Hybrid Framework'** in the sidebar to train models and evaluate benchmarks.")
    with tab3:
        st.info("👈 Click **'Train & Run Hybrid Framework'** in the sidebar to view quantitative backtest results.")
    with tab4:
        st.info("👈 Click **'Train & Run Hybrid Framework'** in the sidebar to view explainability and attention insights.")
