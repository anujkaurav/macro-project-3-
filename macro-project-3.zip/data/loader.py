"""
Market Data Ingestion and Synthetic Data Generation Engine
"""
from typing import Optional
import os
import datetime
import numpy as np
import pandas as pd
import yfinance as yf


class MarketDataLoader:
    """
    Downloads historical OHLCV data from Yahoo Finance with local disk caching
    and automated fallbacks.
    """

    def __init__(self, cache_dir: Optional[str] = None):
        self.cache_dir = cache_dir or os.path.join(os.path.dirname(__file__), "..", "data_cache")
        os.makedirs(self.cache_dir, exist_ok=True)

    def fetch_data(
        self,
        ticker: str = "AAPL",
        start_date: str = "2020-01-01",
        end_date: Optional[str] = None,
        use_cache: bool = True
    ) -> pd.DataFrame:
        """
        Fetches stock data for a given ticker and date range.
        Saves locally as CSV cache to prevent rate-limiting.
        """
        if end_date is None:
            end_date = datetime.date.today().strftime("%Y-%m-%d")

        sanitized_ticker = ticker.replace("^", "").replace("=", "_").replace("/", "_")
        cache_file = os.path.join(self.cache_dir, f"{sanitized_ticker}_{start_date}_{end_date}.csv")

        if use_cache and os.path.exists(cache_file):
            df = pd.read_csv(cache_file, index_col=0, parse_dates=True)
            if not df.empty and len(df) > 50:
                print(f"[DataLoader] Loaded {len(df)} rows for {ticker} from local cache.")
                return self._standardize_columns(df)

        print(f"[DataLoader] Fetching live data for {ticker} ({start_date} to {end_date}) via yfinance...")
        try:
            raw = yf.download(
                ticker,
                start=start_date,
                end=end_date,
                progress=False,
                auto_adjust=True
            )
            if raw is not None and not raw.empty:
                # Handle multi-level columns if returned by newer yfinance
                if isinstance(raw.columns, pd.MultiIndex):
                    raw.columns = [col[0] for col in raw.columns]

                df = self._standardize_columns(raw)
                df.to_csv(cache_file)
                print(f"[DataLoader] Successfully fetched and cached {len(df)} candles for {ticker}.")
                return df
        except Exception as e:
            print(f"[DataLoader] yfinance fetch warning: {e}. Attempting fallback...")

        # If download fails (e.g. offline, rate limit), check for any cached file for this ticker
        for fname in os.listdir(self.cache_dir):
            if fname.startswith(f"{sanitized_ticker}_") and fname.endswith(".csv"):
                alt_path = os.path.join(self.cache_dir, fname)
                df = pd.read_csv(alt_path, index_col=0, parse_dates=True)
                print(f"[DataLoader] Used fallback cached file {fname}.")
                return self._standardize_columns(df)

        print(f"[DataLoader] Generating synthetic market series for {ticker} as offline fallback.")
        return SyntheticMarketGenerator.generate(ticker=ticker, start_date=start_date, end_date=end_date)

    @staticmethod
    def _standardize_columns(df: pd.DataFrame) -> pd.DataFrame:
        """Ensures standard column names: Open, High, Low, Close, Volume."""
        clean = df.copy()
        clean = clean.dropna(how='all')
        clean.columns = [str(c).capitalize() for c in clean.columns]
        req = ['Open', 'High', 'Low', 'Close', 'Volume']
        for col in req:
            if col not in clean.columns:
                # Attempt match
                for c in clean.columns:
                    if col.lower() in c.lower():
                        clean = clean.rename(columns={c: col})
                        break
        # Fill zero volume if missing
        if 'Volume' in clean.columns:
            clean['Volume'] = clean['Volume'].fillna(1000).replace(0, 1000)
        return clean.sort_index()


class SyntheticMarketGenerator:
    """
    Generates realistic synthetic financial time series using a Regime-Switching
    Stochastic Volatility Jump Diffusion model.
    """

    @staticmethod
    def generate(
        ticker: str = "SYNTH_STOCK",
        start_date: str = "2020-01-01",
        end_date: str = "2025-01-01",
        initial_price: float = 150.0,
        seed: int = 42
    ) -> pd.DataFrame:
        np.random.seed(seed)
        date_range = pd.bdate_range(start=start_date, end=end_date)
        n = len(date_range)

        # Regimes: 0 = Bullish low-vol, 1 = Bearish high-vol
        regime = 0
        mu = [0.0006, -0.0004]      # Daily drifts
        sigma = [0.012, 0.025]      # Daily volatilities

        p_stay_bull = 0.98
        p_stay_bear = 0.94

        close = np.zeros(n)
        open_p = np.zeros(n)
        high = np.zeros(n)
        low = np.zeros(n)
        volume = np.zeros(n)

        curr_p = initial_price

        for i in range(n):
            # Transition regime
            if regime == 0 and np.random.rand() > p_stay_bull:
                regime = 1
            elif regime == 1 and np.random.rand() > p_stay_bear:
                regime = 0

            # Jump diffusion
            jump = 0.0
            if np.random.rand() < 0.03:
                jump = np.random.normal(-0.015 if regime == 1 else 0.01, 0.02)

            # Daily return
            ret = np.random.normal(mu[regime], sigma[regime]) + jump
            next_close = curr_p * np.exp(ret)

            # Intraday variations
            intraday_vol = sigma[regime] * np.sqrt(0.5)
            day_open = curr_p * (1.0 + np.random.normal(0, intraday_vol * 0.3))
            max_c_o = max(day_open, next_close)
            min_c_o = min(day_open, next_close)

            day_high = max_c_o * (1.0 + abs(np.random.normal(0, intraday_vol)))
            day_low = min_c_o * (1.0 - abs(np.random.normal(0, intraday_vol)))

            # Volume correlates with volatility and return magnitude
            vol_base = 20_000_000 if regime == 0 else 45_000_000
            day_vol = vol_base * (1.0 + 5.0 * abs(ret)) * np.random.lognormal(0, 0.3)

            open_p[i] = round(day_open, 2)
            high[i] = round(day_high, 2)
            low[i] = round(day_low, 2)
            close[i] = round(next_close, 2)
            volume[i] = int(day_vol)

            curr_p = next_close

        df = pd.DataFrame({
            'Open': open_p,
            'High': high,
            'Low': low,
            'Close': close,
            'Volume': volume
        }, index=date_range)
        df.index.name = 'Date'
        return df
