"""
Market Data Preprocessor and Target Labeling Engine
Strictly prevents lookahead bias by fitting scalers only on training partitions.
"""
from typing import Tuple, List, Optional, Dict
import numpy as np
import pandas as pd
from sklearn.preprocessing import RobustScaler, StandardScaler
from config import ModelConfig


class MarketDataPreprocessor:
    """
    Handles feature selection, target labeling, data cleaning,
    and lookahead-free chronological train/val/test splitting.
    """

    def __init__(self, config: Optional[ModelConfig] = None):
        self.cfg = config or ModelConfig()
        self.feature_scaler: Optional[RobustScaler] = None
        self.target_scaler: Optional[StandardScaler] = None
        self.feature_columns: List[str] = []

    def prepare_dataset(
        self,
        df: pd.DataFrame
    ) -> Tuple[pd.DataFrame, pd.Series, pd.Series]:
        """
        Generates target labels, drops warm-up NaNs, and separates features from targets.
        
        Returns:
            features_df: Clean DataFrame containing all predictor features
            target_clf: Binary classification target (1 = Up/Bullish, 0 = Down/Bearish)
            target_reg: Continuous forward return regression target
        """
        processed = df.copy()

        # Target 1: Forward Return (k-step ahead percentage return)
        horizon = self.cfg.forecast_horizon
        processed['Forward_Return'] = processed['Close'].shift(-horizon) / processed['Close'] - 1.0

        # Target 2: Trend Classification (1 if return > threshold, else 0)
        # Using threshold allows filtering out flat noisy market drift
        processed['Target_Class'] = (
            processed['Forward_Return'] > self.cfg.classification_threshold
        ).astype(int)

        # Drop the last horizon rows where future targets are unknown NaNs
        processed = processed.iloc[:-horizon]

        # Drop warm-up rows where moving averages/indicators contain NaNs
        processed = processed.dropna()

        # Candidate predictor features: Exclude raw future targets and non-stationary raw prices
        # We keep normalized indicators, ratios, oscillator values, returns, and pattern signals.
        exclude_cols = {
            'Forward_Return', 'Target_Class',
            # We preserve raw Close / Open / High / Low / Volume for reference and backtesting,
            # but standard models use normalized indicators.
        }

        # Select all numeric feature columns
        numeric_cols = processed.select_dtypes(include=[np.number]).columns.tolist()
        self.feature_columns = [c for c in numeric_cols if c not in exclude_cols]

        features_df = processed[self.feature_columns]
        target_clf = processed['Target_Class']
        target_reg = processed['Forward_Return']

        return features_df, target_clf, target_reg

    def split_chronological(
        self,
        features: pd.DataFrame,
        target: pd.Series
    ) -> Dict[str, Tuple[pd.DataFrame, pd.Series]]:
        """
        Performs walk-forward chronological train/val/test splitting.
        Strictly preserves time ordering (NO random shuffling).
        """
        n = len(features)
        train_end = int(n * self.cfg.train_ratio)
        val_end = int(n * (self.cfg.train_ratio + self.cfg.val_ratio))

        X_train = features.iloc[:train_end]
        y_train = target.iloc[:train_end]

        X_val = features.iloc[train_end:val_end]
        y_val = target.iloc[train_end:val_end]

        X_test = features.iloc[val_end:]
        y_test = target.iloc[val_end:]

        # Fit RobustScaler ONLY on the training slice
        self.feature_scaler = RobustScaler()
        X_train_scaled = pd.DataFrame(
            self.feature_scaler.fit_transform(X_train),
            index=X_train.index,
            columns=X_train.columns
        )
        X_val_scaled = pd.DataFrame(
            self.feature_scaler.transform(X_val),
            index=X_val.index,
            columns=X_val.columns
        )
        X_test_scaled = pd.DataFrame(
            self.feature_scaler.transform(X_test),
            index=X_test.index,
            columns=X_test.columns
        )

        return {
            "train": (X_train_scaled, y_train),
            "val": (X_val_scaled, y_val),
            "test": (X_test_scaled, y_test),
            "unscaled_train": (X_train, y_train),
            "unscaled_val": (X_val, y_val),
            "unscaled_test": (X_test, y_test)
        }
