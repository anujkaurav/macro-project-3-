"""
Time Series Sliding Window Sequence Builder
Produces aligned 3D tensors for PyTorch DL and 2D arrays for tabular ML models.
"""
from typing import Tuple, List
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset


class StockWindowDataset(Dataset):
    """PyTorch Dataset for temporal time series windows."""

    def __init__(self, sequences: np.ndarray, targets: np.ndarray):
        self.sequences = torch.tensor(sequences, dtype=torch.float32)
        # Classification targets are float32 for BCEWithLogitsLoss or int64 for CrossEntropy
        self.targets = torch.tensor(targets, dtype=torch.float32)

    def __len__(self) -> int:
        return len(self.sequences)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        return self.sequences[idx], self.targets[idx]


class TimeSeriesSequenceBuilder:
    """
    Transforms continuous tabular data into sliding lookback windows:
    Lookback window W = [t - W + 1, ..., t] -> Target = y_t
    """

    def __init__(self, lookback_window: int = 30):
        self.lookback = lookback_window

    def build_sequences(
        self,
        features_df: pd.DataFrame,
        target_series: pd.Series
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, pd.Index]:
        """
        Creates aligned 3D DL sequences and 2D ML tabular representations.

        Returns:
            X_seq: Shape (samples, lookback, num_features) for DL models
            X_tabular: Shape (samples, num_features) at time t for ML models
            y: Shape (samples,) future targets
            aligned_dates: DatetimeIndex corresponding to time t
        """
        feature_vals = features_df.values
        target_vals = target_series.values
        dates = features_df.index

        n = len(features_df)
        if n <= self.lookback:
            raise ValueError(
                f"Insufficient sample length ({n}) for lookback window ({self.lookback})."
            )

        num_samples = n - self.lookback + 1
        num_features = feature_vals.shape[1]

        X_seq = np.zeros((num_samples, self.lookback, num_features), dtype=np.float32)
        X_tabular = np.zeros((num_samples, num_features), dtype=np.float32)
        y = np.zeros(num_samples, dtype=np.float32)
        aligned_dates = []

        for i in range(num_samples):
            # Window from i to i + lookback
            window = feature_vals[i : i + self.lookback]
            X_seq[i] = window
            # Tabular features at current day t (the end of the window)
            X_tabular[i] = feature_vals[i + self.lookback - 1]
            y[i] = target_vals[i + self.lookback - 1]
            aligned_dates.append(dates[i + self.lookback - 1])

        return X_seq, X_tabular, y, pd.Index(aligned_dates)
